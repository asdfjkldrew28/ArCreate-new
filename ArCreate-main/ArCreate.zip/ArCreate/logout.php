<?php
session_start();

// Check if user confirmed logout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_logout'])) {
    // User confirmed logout - clear session and redirect
    $_SESSION = array();
    
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    session_destroy();
    header('Location: login.php?logout=success');
    exit;
}

// If not POST request, show confirmation page
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Logout Confirmation</title>
<!-- Include SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

.hidden-form {
    display: none;
}
</style>
</head>
<body>

<script>
document.addEventListener('DOMContentLoaded', function() {
    Swal.fire({
        title: '🚪 Logout Confirmation',
        html: `
            <div style="text-align: center;">
                <div style="font-size: 3rem; margin-bottom: 15px;">👋</div>
                <p style="font-size: 1.1rem; margin-bottom: 10px;">
                    <strong>Are you sure you want to log out?</strong>
                </p>
                <p style="color: #666; font-size: 0.9rem;">
                    You will need to sign in again to access the system.
                </p>
            </div>
        `,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#667eea',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes',
        cancelButtonText: 'Cancel',
        reverseButtons: true,
        allowOutsideClick: false,
        allowEscapeKey: true,
        backdrop: true
    }).then((result) => {
        if (result.isConfirmed) {
            // User confirmed logout - submit form to proceed
            const form = document.getElementById('logoutForm');
            form.submit();
        } else {
            // User cancelled - redirect back to previous page or index.php
            const referrer = document.referrer;
            let redirectUrl = 'index.php';
            
            // Check if referrer is from the same domain and not the logout page itself
            if (referrer && referrer.includes(window.location.origin) && 
                !referrer.includes('logout.php') && 
                !referrer.includes('login.php')) {
                redirectUrl = referrer;
            }
            
            window.location.href = redirectUrl;
        }
    });
});

// Additional styling for SweetAlert
const style = document.createElement('style');
style.textContent = `
    .swal2-popup {
        border-radius: 20px !important;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2) !important;
    }
    
    .swal2-confirm {
        border-radius: 25px !important;
        padding: 12px 30px !important;
        font-weight: 600 !important;
    }
    
    .swal2-cancel {
        border-radius: 25px !important;
        padding: 12px 30px !important;
        font-weight: 600 !important;
    }
    
    .swal2-title {
        color: #333 !important;
        font-size: 1.5rem !important;
    }
`;
document.head.appendChild(style);
</script>

<!-- Hidden form for logout confirmation -->
<form id="logoutForm" method="post" class="hidden-form">
    <input type="hidden" name="confirm_logout" value="1">
</form>

</body>
</html>
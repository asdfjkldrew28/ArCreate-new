<?php
session_start();
include 'config.php';

// Check for success/error messages from delete operations
if (isset($_SESSION['delete_success'])) {
    echo '<div id="deleteSuccess" style="display:none;">' . $_SESSION['delete_success'] . '</div>';
    unset($_SESSION['delete_success']);
}

if (isset($_SESSION['delete_error'])) {
    echo '<div id="deleteError" style="display:none;">' . $_SESSION['delete_error'] . '</div>';
    unset($_SESSION['delete_error']);
}

if (!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit; 
}

include 'db_connect.php';

// Check for pending password reset requests (for admin only)
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    $reset_request_count = $conn->query("SELECT COUNT(*) as count FROM password_reset_requests WHERE status = 'pending'")->fetch_assoc()['count'];
    
    if ($reset_request_count > 0) {
        echo '<div id="resetRequestAlert" style="display:none;">You have ' . $reset_request_count . ' pending password reset request(s).</div>';
    }
}

// Calculate quick stats for construction materials
$total_items = 0;
$low_stock_count = 0;
$out_of_stock_count = 0;

// Get material statistics by category
$categories = [
    'construction' => ['icon' => '🏗️', 'color' => '#667eea'],
    'hardware' => ['icon' => '🔧', 'color' => '#ff9e6d'],
    'electrical' => ['icon' => '⚡', 'color' => '#ffd166'],
    'plumbing' => ['icon' => '🚰', 'color' => '#56ab91'],
    'finishing' => ['icon' => '🎨', 'color' => '#a78bfa'],
    'tools' => ['icon' => '🛠️', 'color' => '#f97316'],
    'safety' => ['icon' => '🦺', 'color' => '#ef4444'],
    'office' => ['icon' => '📁', 'color' => '#6b7280']
];

$category_stats = [];
foreach ($categories as $category => $info) {
    $query = "SELECT COUNT(*) as count, 
                     SUM(CASE WHEN quantity <= 0 THEN 1 ELSE 0 END) as out_of_stock,
                     SUM(CASE WHEN quantity > 0 AND quantity <= min_stock_level THEN 1 ELSE 0 END) as low_stock
              FROM materials WHERE category = '$category'";
    $result = $conn->query($query);
    if ($result) {
        $category_stats[$category] = $result->fetch_assoc();
        $total_items += $category_stats[$category]['count'];
        $out_of_stock_count += $category_stats[$category]['out_of_stock'];
        $low_stock_count += $category_stats[$category]['low_stock'];
    }
}

// Get total inventory value
$inventory_value = $conn->query("SELECT SUM(quantity * unit_price) as total_value FROM materials")->fetch_assoc()['total_value'];

// Search functionality
if (isset($_POST['search']) && !empty($_POST['search'])) {
    $search = $conn->real_escape_string($_POST['search']);
    $query = "SELECT * FROM materials 
              WHERE material_name LIKE '%$search%' 
              OR category LIKE '%$search%' 
              OR description LIKE '%$search%' 
              OR location LIKE '%$search%'
              ORDER BY material_name ASC";
} else {
    $query = "SELECT * FROM materials ORDER BY material_name ASC";
}

$materials_result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ArCreate - Construction Materials Inventory</title>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
    --primary: #667eea;
    --primary-dark: #5a67d8;
    --construction: #f59e0b;
    --hardware: #ef4444;
    --electrical: #fbbf24;
    --plumbing: #06b6d4;
    --finishing: #8b5cf6;
    --safety: #dc2626;
    --tools: #ea580c;
}

body {
    background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    line-height: 1.6;
    color: #333;
    margin: 0;
    min-height: 100vh;
}

.container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 20px;
}

/* Header Styles */
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: rgba(255, 255, 255, 0.95);
    padding: 25px;
    border-radius: 20px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    margin-bottom: 30px;
    backdrop-filter: blur(10px);
}

.header-content {
    display: flex;
    align-items: center;
    gap: 20px;
}

.header-icon {
    font-size: 3rem;
    color: var(--primary);
}

.header h1 {
    color: #1e40af;
    font-size: 2.5rem;
    margin-bottom: 5px;
}

.header-subtitle {
    color: #666;
    font-size: 1rem;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 1.2rem;
}

.user-details {
    text-align: right;
}

.user-name {
    font-weight: 600;
    color: #333;
    margin-bottom: 5px;
}

.role-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}

.role-admin { background: linear-gradient(135deg, #667eea, #764ba2); color: white; }
.role-foreman { background: linear-gradient(135deg, #f59e0b, #d97706); color: white; }
.role-client { background: linear-gradient(135deg, #6b7280, #4b5563); color: white; }

/* Stats Container */
.stats-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: rgba(255, 255, 255, 0.95);
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
    gap: 20px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    backdrop-filter: blur(10px);
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: white;
}

.stat-icon.total {
    background: linear-gradient(135deg, #667eea, #764ba2);
}

.stat-icon.construction {
    background: linear-gradient(135deg, #f59e0b, #d97706);
}

.stat-icon.low {
    background: linear-gradient(135deg, #f59e0b, #d97706);
}

.stat-icon.out {
    background: linear-gradient(135deg, #ef4444, #dc2626);
}

.stat-content {
    flex: 1;
}

.stat-value {
    font-size: 2rem;
    font-weight: bold;
    color: #333;
    margin-bottom: 5px;
}

.stat-label {
    color: #666;
    font-size: 0.9rem;
    font-weight: 600;
}

/* Category Card */
.category-card {
    background: white;
    padding: 15px;
    border-radius: 10px;
    border-left: 4px solid #667eea;
}

/* Actions Bar - UPDATED */
.actions-bar {
    background: rgba(255, 255, 255, 0.95);
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    margin-bottom: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    backdrop-filter: blur(10px);
}

.search-container {
    display: flex;
    align-items: center;
    gap: 15px;
    flex: 1;
}

.search-box {
    position: relative;
    flex: 1;
    min-width: 300px;
}

.search-icon {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #666;
}

.search-input {
    width: 100%;
    padding: 12px 15px 12px 45px;
    border: 2px solid #e5e7eb;
    border-radius: 10px;
    font-size: 1rem;
    transition: all 0.3s ease;
    box-sizing: border-box;
}

.search-input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.search-btn {
    padding: 12px 24px;
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    white-space: nowrap;
}

.search-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.actions-buttons {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    flex-shrink: 0;
}

/* Button Styles */
.btn {
    padding: 12px 20px;
    border: none;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    white-space: nowrap;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: white;
}

.btn-success {
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
}

.btn-warning {
    background: linear-gradient(135deg, #f59e0b, #d97706);
    color: white;
}

.btn-danger {
    background: linear-gradient(135deg, #ef4444, #dc2626);
    color: white;
}

/* Table Container */
.table-container {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
    margin-bottom: 30px;
}

.materials-table {
    width: 100%;
    border-collapse: collapse;
}

.materials-table th {
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: white;
    padding: 20px 15px;
    text-align: left;
    font-weight: 600;
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.materials-table td {
    padding: 15px;
    border-bottom: 1px solid #e5e7eb;
    vertical-align: middle;
}

.materials-table tr:hover {
    background: rgba(102, 126, 234, 0.05);
}

.materials-table tr:last-child td {
    border-bottom: none;
}

/* Category Badge */
.category-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 10px;
    border-radius: 15px;
    font-size: 0.75rem;
    font-weight: 600;
}

.category-construction { background: rgba(245, 158, 11, 0.1); color: #f59e0b; }
.category-hardware { background: rgba(239, 68, 68, 0.1); color: #ef4444; }
.category-electrical { background: rgba(251, 191, 36, 0.1); color: #f59e0b; }
.category-plumbing { background: rgba(6, 182, 212, 0.1); color: #0891b2; }
.category-finishing { background: rgba(139, 92, 246, 0.1); color: #8b5cf6; }
.category-tools { background: rgba(234, 88, 12, 0.1); color: #ea580c; }
.category-safety { background: rgba(220, 38, 38, 0.1); color: #dc2626; }
.category-office { background: rgba(107, 114, 128, 0.1); color: #6b7280; }

.stock-alert {
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 0.7rem;
    font-weight: 600;
    margin-top: 5px;
}

.stock-normal { background: rgba(16, 185, 129, 0.1); color: #10b981; }
.stock-low { background: rgba(245, 158, 11, 0.1); color: #f59e0b; }
.stock-critical { background: rgba(239, 68, 68, 0.1); color: #ef4444; }

.quantity-cell {
    font-weight: 600;
    text-align: center;
}

.material-value {
    font-weight: 600;
    color: var(--primary);
}

.stock-indicator {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    margin-right: 8px;
}

.stock-indicator.normal {
    background: #10b981;
}

.stock-indicator.low {
    background: #f59e0b;
}

.stock-indicator.critical {
    background: #ef4444;
}

/* Action Buttons */
.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.action-btn {
    padding: 6px 12px;
    border: none;
    border-radius: 8px;
    font-size: 0.8rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.action-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.edit-btn {
    background: rgba(59, 130, 246, 0.1);
    color: #3b82f6;
}

.delete-btn {
    background: rgba(239, 68, 68, 0.1);
    color: #ef4444;
}

.view-btn {
    background: rgba(16, 185, 129, 0.1);
    color: #10b981;
}

/* No Results */
.no-results {
    text-align: center;
    padding: 60px 20px;
    color: #666;
}

.no-results-icon {
    font-size: 4rem;
    margin-bottom: 20px;
    opacity: 0.5;
}

.no-results h3 {
    margin-bottom: 10px;
    color: #333;
}

/* Responsive Design */
@media (max-width: 1024px) {
    .container {
        padding: 15px;
    }
    
    .header {
        flex-direction: column;
        gap: 20px;
        text-align: center;
    }
    
    .user-info {
        flex-direction: column;
        text-align: center;
    }
    
    .actions-bar {
        flex-direction: column;
        gap: 15px;
    }
    
    .search-container {
        max-width: 100%;
        width: 100%;
    }
    
    .search-box {
        min-width: 200px;
    }
    
    .actions-buttons {
        justify-content: center;
        width: 100%;
    }
}

@media (max-width: 768px) {
    .stats-container {
        grid-template-columns: 1fr;
    }
    
    .header h1 {
        font-size: 2rem;
    }
    
    .header-icon {
        font-size: 2rem;
    }
    
    .table-container {
        overflow-x: auto;
    }
    
    .materials-table {
        min-width: 800px;
    }
    
    .action-buttons {
        flex-direction: column;
    }
    
    .action-btn {
        justify-content: center;
    }
    
    .search-container {
        flex-direction: column;
        align-items: stretch;
    }
    
    .search-box {
        min-width: auto;
    }
    
    .search-btn {
        width: 100%;
        justify-content: center;
    }
}

@media (max-width: 480px) {
    .container {
        padding: 10px;
    }
    
    .header {
        padding: 20px;
    }
    
    .actions-bar {
        padding: 20px;
    }
    
    .btn {
        padding: 10px 15px;
        font-size: 0.8rem;
    }
    
    .actions-buttons {
        flex-direction: column;
    }
    
    .actions-buttons .btn {
        width: 100%;
        justify-content: center;
    }
}
</style>
</head>
<body>

<div class="container">
    <!-- Header Section -->
    <div class="header">
        <div class="header-content">
            <div class="logo-container">
                <?php if (defined('SITE_LOGO') && file_exists(SITE_LOGO)): ?>
                    <img src="<?php echo SITE_LOGO; ?>" alt="ArCreate Logo" style="height: 60px;">
                <?php else: ?>
                    <div class="header-icon">
                        <i class="fas fa-hard-hat"></i>
                    </div>
                <?php endif; ?>
            </div>
            <div>
                <h1>ArCreate Materials Inventory</h1>
                <div class="header-subtitle">Construction Materials Management System</div>
            </div>
        </div>
        
        <div class="user-info">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['full_name'] ?? $_SESSION['username'], 0, 1)); ?>
            </div>
            <div class="user-details">
                <div class="user-name"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></div>
                <div class="user-role">
                    <i class="fas fa-user-tag"></i>
                    <span class="role-badge role-<?php echo $_SESSION['role']; ?>">
                        <?php 
                        $role_display = [
                            'admin' => '👑 Admin',
                            'foreman' => '👷 Foreman',
                            'client' => '👤 Client'
                        ];
                        echo $role_display[$_SESSION['role']] ?? ucfirst($_SESSION['role']); 
                        ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Construction Dashboard Stats -->
    <div class="stats-container">
        <div class="stat-card">
            <div class="stat-icon total">
                <i class="fas fa-boxes"></i>
            </div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $total_items; ?></div>
                <div class="stat-label">Total Materials</div>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon construction">
                <i class="fas fa-hard-hat"></i>
            </div>
            <div class="stat-content">
                <div class="stat-value">₱<?php echo number_format($inventory_value, 2); ?></div>
                <div class="stat-label">Inventory Value</div>
            </div>
        </div>
        
        <?php if ($low_stock_count > 0): ?>
        <div class="stat-card">
            <div class="stat-icon low">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $low_stock_count; ?></div>
                <div class="stat-label">Low Stock Items</div>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($out_of_stock_count > 0): ?>
        <div class="stat-card">
            <div class="stat-icon out">
                <i class="fas fa-times-circle"></i>
            </div>
            <div class="stat-content">
                <div class="stat-value"><?php echo $out_of_stock_count; ?></div>
                <div class="stat-label">Out of Stock</div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Category Breakdown -->
    <div style="background: white; padding: 25px; border-radius: 15px; margin-bottom: 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
        <h3 style="margin-bottom: 20px; color: #333;"><i class="fas fa-layer-group"></i> Materials by Category</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px;">
            <?php foreach ($category_stats as $category => $stats): 
                if ($stats['count'] > 0): 
                    $category_info = $categories[$category];
            ?>
            <div class="category-card" style="border-left-color: <?php echo $category_info['color']; ?>;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <div style="font-size: 1.5rem;"><?php echo $category_info['icon']; ?></div>
                    <div>
                        <div style="font-weight: 600; color: #333;"><?php echo ucfirst($category); ?></div>
                        <div style="font-size: 1.5rem; font-weight: bold; color: <?php echo $category_info['color']; ?>;"><?php echo $stats['count']; ?></div>
                    </div>
                </div>
                <div style="font-size: 0.8rem; color: #666;">
                    <?php if ($stats['out_of_stock'] > 0): ?>
                        <span style="color: #ef4444;"><?php echo $stats['out_of_stock']; ?> out of stock</span><br>
                    <?php endif; ?>
                    <?php if ($stats['low_stock'] > 0): ?>
                        <span style="color: #f59e0b;"><?php echo $stats['low_stock']; ?> low stock</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; endforeach; ?>
        </div>
    </div>

    <!-- Actions Bar - UPDATED -->
    <div class="actions-bar">
        <form method="post" action="" class="search-container">
            <div class="search-box">
                <i class="fas fa-search search-icon"></i>
                <input type="text" name="search" placeholder="Search materials by name, category, or location..." 
                       class="search-input" 
                       value="<?php echo isset($_POST['search']) ? htmlspecialchars($_POST['search']) : ''; ?>">
            </div>
            <button type="submit" class="search-btn">
                <i class="fas fa-search"></i> Search
            </button>
        </form>
        
        <div class="actions-buttons">
            <?php if (in_array($_SESSION['role'], ['admin', 'foreman'])): ?>
                <a href="add_material.php" class="btn btn-success" id="addMaterialBtn">
                    <i class="fas fa-plus"></i> Add Material
                </a>
            <?php endif; ?>
            
            <?php
                // Fixed button rendering without \n
                if ($_SESSION['role'] === 'admin') {
                    echo '<a href="dashboard_admin.php" class="btn btn-primary">
                            <i class="fas fa-crown"></i> Admin Dashboard
                          </a>';
                } elseif ($_SESSION['role'] === 'foreman') {
                    echo '<a href="dashboard_foreman.php" class="btn btn-primary">
                            <i class="fas fa-hard-hat"></i> Foreman Dashboard
                          </a>';
                } elseif ($_SESSION['role'] === 'client') {
                    echo '<a href="client_dashboard.php" class="btn btn-primary">
                            <i class="fas fa-user-circle"></i> Client Portal
                          </a>';
                }
            ?>
            
            <a href="logout.php" class="btn btn-danger">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <!-- Materials Table with Construction Categories -->
    <div class="table-container">
        <table class="materials-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Material Name</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total Value</th>
                    <th>Location</th>
                    <th>Stock Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($materials_result && $materials_result->num_rows > 0): ?>
                    <?php while($row = $materials_result->fetch_assoc()): 
                        // Calculate stock level
                        $quantity = $row['quantity'];
                        $min_stock = $row['min_stock_level'] ?? 10;
                        $reorder_level = $row['reorder_level'] ?? 5;
                        
                        $stock_class = 'stock-normal';
                        $stock_text = 'In Stock';
                        
                        if ($quantity <= 0) {
                            $stock_class = 'stock-critical';
                            $stock_text = 'Out of Stock';
                        } elseif ($quantity <= $reorder_level) {
                            $stock_class = 'stock-critical';
                            $stock_text = 'Critical Low!';
                        } elseif ($quantity <= $min_stock) {
                            $stock_class = 'stock-low';
                            $stock_text = 'Low Stock';
                        }
                        
                        $total_value = $quantity * $row['unit_price'];
                    ?>
                        <tr>
                            <td>#<?php echo $row['material_id']; ?></td>
                            <td>
                                <div style="font-weight: 600; color: #1e293b;">
                                    <?php echo htmlspecialchars($row['material_name']); ?>
                                </div>
                                <div class="stock-alert <?php echo $stock_class; ?>">
                                    <?php echo $stock_text; ?>
                                </div>
                            </td>
                            <td>
                                <span class="category-badge category-<?php echo $row['category']; ?>">
                                    <?php echo $categories[$row['category']]['icon'] ?? '📦'; ?>
                                    <?php echo ucfirst($row['category']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($row['description'] ?: 'No description'); ?></td>
                            <td class="quantity-cell">
                                <span class="stock-indicator <?php echo str_replace('stock-', '', $stock_class); ?>"></span>
                                <?php echo $quantity; ?> <?php echo htmlspecialchars($row['unit']); ?>
                            </td>
                            <td class="material-value">₱<?php echo number_format($row['unit_price'], 2); ?></td>
                            <td class="material-value">₱<?php echo number_format($total_value, 2); ?></td>
                            <td>
                                <i class="fas fa-map-marker-alt" style="color: #6b7280; margin-right: 5px;"></i>
                                <?php echo htmlspecialchars($row['location'] ?: 'Not specified'); ?>
                            </td>
                            <td>
                                <span class="stock-alert <?php echo $stock_class; ?>">
                                    <?php echo $stock_text; ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <?php if (in_array($_SESSION['role'], ['admin', 'foreman'])): ?>
                                        <a class="action-btn edit-btn" href="edit_material.php?id=<?php echo $row['material_id']; ?>" title="Edit Material">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <button class="action-btn delete-btn delete-item-btn" 
                                                data-item-id="<?php echo $row['material_id']; ?>"
                                                data-item-name="<?php echo htmlspecialchars($row['material_name']); ?>"
                                                title="Delete Material">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                        <a class="action-btn view-btn" href="view_material.php?id=<?php echo $row['material_id']; ?>" title="View Details">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                    <?php elseif ($_SESSION['role'] === 'client'): ?>
                                        <a class="action-btn view-btn" href="view_material.php?id=<?php echo $row['material_id']; ?>" title="View Details">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <a class="action-btn" href="request_quotation.php?material_id=<?php echo $row['material_id']; ?>" style="background: rgba(16, 185, 129, 0.1); color: #10b981;">
                                            <i class="fas fa-file-invoice-dollar"></i> Quote
                                        </a>
                                    <?php else: ?>
                                        <span style="color: #666; font-style: italic;">View Only</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10">
                            <div class="no-results">
                                <div class="no-results-icon">
                                    <i class="fas fa-box-open"></i>
                                </div>
                                <h3>No Materials Found</h3>
                                <p>No construction materials found in inventory.</p>
                                <?php if (in_array($_SESSION['role'], ['admin', 'foreman'])): ?>
                                    <a href="add_material.php" class="btn btn-success" style="margin-top: 15px;">
                                        <i class="fas fa-plus"></i> Add Your First Material
                                    </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
// Auto-refresh every 2 minutes for real-time updates
setTimeout(function() {
    location.reload();
}, 120000);

// Delete confirmation for materials
document.addEventListener('DOMContentLoaded', function() {
    const deleteButtons = document.querySelectorAll('.delete-item-btn');
    
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const itemId = this.getAttribute('data-item-id');
            const itemName = this.getAttribute('data-item-name');
            
            Swal.fire({
                title: 'Delete Material?',
                html: `
                    <div style="text-align: center;">
                        <div style="font-size: 4rem; margin-bottom: 15px; color: #ef4444;">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <p style="font-size: 1.2rem; margin-bottom: 10px;">
                            Delete construction material:<br>
                            <strong>"${itemName}"</strong>?
                        </p>
                        <p style="color: #ef4444; font-weight: 600; font-size: 1rem;">
                            This will remove the material from inventory!
                        </p>
                    </div>
                `,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#6b7280',
                confirmButtonText: 'Yes, Delete',
                cancelButtonText: 'Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `delete_material.php?id=${itemId}`;
                }
            });
        });
    });
    
    // Show success/error messages
    const deleteSuccess = document.getElementById('deleteSuccess');
    const deleteError = document.getElementById('deleteError');
    
    if (deleteSuccess) {
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: deleteSuccess.textContent,
            confirmButtonColor: '#667eea',
            timer: 3000,
            timerProgressBar: true
        });
    }
    
    if (deleteError) {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: deleteError.textContent,
            confirmButtonColor: '#ef4444'
        });
    }

    // Show password reset request notification for admin
    const resetRequestAlert = document.getElementById('resetRequestAlert');
    if (resetRequestAlert) {
        Swal.fire({
            title: 'Password Reset Requests',
            html: `
                <div style="text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 15px; color: #f59e0b;">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <p style="font-size: 1.1rem;">
                        ${resetRequestAlert.textContent}
                    </p>
                    <p style="color: #666; margin-top: 10px;">
                        Please go to User Management to process these requests.
                    </p>
                </div>
            `,
            icon: 'warning',
            confirmButtonText: 'Go to User Management',
            confirmButtonColor: '#f59e0b',
            showCancelButton: true,
            cancelButtonText: 'Later',
            cancelButtonColor: '#6b7280'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'manage_users.php';
            }
        });
    }
});
</script>
</body>
</html>
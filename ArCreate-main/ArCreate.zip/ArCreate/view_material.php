<?php
// view_material.php - View material details
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

include 'db_connect.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch material details
$stmt = $conn->prepare("SELECT m.*, s.supplier_name FROM materials m LEFT JOIN suppliers s ON m.supplier_id = s.supplier_id WHERE m.material_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$material = $result->fetch_assoc();

if (!$material) {
    header('Location: index.php');
    exit;
}

// Calculate stock status
$quantity = $material['quantity'];
$min_stock = $material['min_stock_level'] ?? 10;
$reorder_level = $material['reorder_level'] ?? 5;

$stock_class = 'stock-normal';
$stock_text = 'In Stock';

if ($quantity <= 0) {
    $stock_class = 'stock-critical';
    $stock_text = 'Out of Stock';
} elseif ($quantity <= $reorder_level) {
    $stock_class = 'stock-critical';
    $stock_text = 'Critical Low!';
} elseif ($quantity <= $min_stock) {
    $stock_class = 'stock-low';
    $stock_text = 'Low Stock';
}

$total_value = $quantity * $material['unit_price'];
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>View Material - ArCreate</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #1e40af;
            font-size: 2rem;
        }
        
        .material-details {
            display: grid;
            gap: 20px;
        }
        
        .detail-card {
            background: #f8fafc;
            padding: 20px;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }
        
        .detail-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 15px;
        }
        
        .detail-label {
            font-weight: 600;
            color: #4b5563;
            margin-bottom: 5px;
        }
        
        .detail-value {
            color: #1f2937;
            font-size: 1.1rem;
        }
        
        .stock-status {
            padding: 10px 15px;
            border-radius: 10px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .stock-normal { background: rgba(16, 185, 129, 0.1); color: #10b981; }
        .stock-low { background: rgba(245, 158, 11, 0.1); color: #f59e0b; }
        .stock-critical { background: rgba(239, 68, 68, 0.1); color: #ef4444; }
        
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-secondary {
            background: #f3f4f6;
            color: #4b5563;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .value-display {
            font-size: 1.5rem;
            font-weight: bold;
            color: #1e40af;
        }
        
        .category-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .category-construction { background: rgba(245, 158, 11, 0.1); color: #f59e0b; }
        .category-hardware { background: rgba(239, 68, 68, 0.1); color: #ef4444; }
        .category-electrical { background: rgba(251, 191, 36, 0.1); color: #f59e0b; }
        .category-plumbing { background: rgba(6, 182, 212, 0.1); color: #0891b2; }
        .category-finishing { background: rgba(139, 92, 246, 0.1); color: #8b5cf6; }
        .category-tools { background: rgba(234, 88, 12, 0.1); color: #ea580c; }
        .category-safety { background: rgba(220, 38, 38, 0.1); color: #dc2626; }
        .category-office { background: rgba(107, 114, 128, 0.1); color: #6b7280; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div style="font-size: 2rem; color: #667eea;">
                <i class="fas fa-info-circle"></i>
            </div>
            <div>
                <h1>Material Details</h1>
                <p style="color: #6b7280;">Complete information about this construction material</p>
            </div>
        </div>
        
        <div class="material-details">
            <!-- Basic Information -->
            <div class="detail-card">
                <h3 style="margin-bottom: 20px; color: #1e40af;">📋 Basic Information</h3>
                <div class="detail-row">
                    <div>
                        <div class="detail-label">Material Name</div>
                        <div class="detail-value"><?php echo htmlspecialchars($material['material_name']); ?></div>
                    </div>
                    <div>
                        <div class="detail-label">Category</div>
                        <div>
                            <span class="category-badge category-<?php echo $material['category']; ?>">
                                <?php 
                                $category_icons = [
                                    'construction' => '🏗️',
                                    'hardware' => '🔧',
                                    'electrical' => '⚡',
                                    'plumbing' => '🚰',
                                    'finishing' => '🎨',
                                    'tools' => '🛠️',
                                    'safety' => '🦺',
                                    'office' => '📁'
                                ];
                                echo $category_icons[$material['category']] ?? '📦';
                                ?>
                                <?php echo ucfirst($material['category']); ?>
                            </span>
                        </div>
                    </div>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <div class="detail-label">Description</div>
                    <div class="detail-value" style="padding: 10px; background: white; border-radius: 5px; min-height: 50px;">
                        <?php echo htmlspecialchars($material['description'] ?: 'No description provided'); ?>
                    </div>
                </div>
                
                <div class="detail-row">
                    <div>
                        <div class="detail-label">Storage Location</div>
                        <div class="detail-value">
                            <i class="fas fa-map-marker-alt" style="color: #6b7280;"></i>
                            <?php echo htmlspecialchars($material['location'] ?: 'Not specified'); ?>
                        </div>
                    </div>
                    <div>
                        <div class="detail-label">Supplier</div>
                        <div class="detail-value">
                            <?php echo htmlspecialchars($material['supplier_name'] ?: 'No supplier assigned'); ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Stock Information -->
            <div class="detail-card">
                <h3 style="margin-bottom: 20px; color: #1e40af;">📊 Stock Information</h3>
                <div class="detail-row">
                    <div>
                        <div class="detail-label">Current Quantity</div>
                        <div class="value-display">
                            <?php echo $quantity; ?> <?php echo htmlspecialchars($material['unit']); ?>
                        </div>
                    </div>
                    <div>
                        <div class="detail-label">Stock Status</div>
                        <div class="stock-status <?php echo $stock_class; ?>">
                            <i class="fas fa-circle" style="font-size: 8px;"></i>
                            <?php echo $stock_text; ?>
                        </div>
                    </div>
                </div>
                
                <div class="detail-row">
                    <div>
                        <div class="detail-label">Unit Price</div>
                        <div class="value-display">₱<?php echo number_format($material['unit_price'], 2); ?></div>
                    </div>
                    <div>
                        <div class="detail-label">Total Value</div>
                        <div class="value-display">₱<?php echo number_format($total_value, 2); ?></div>
                    </div>
                </div>
            </div>
            
            <!-- Stock Levels -->
            <div class="detail-card">
                <h3 style="margin-bottom: 20px; color: #1e40af;">⚠️ Stock Levels</h3>
                <div class="detail-row">
                    <div>
                        <div class="detail-label">Minimum Stock Level</div>
                        <div class="detail-value"><?php echo $min_stock; ?> <?php echo htmlspecialchars($material['unit']); ?></div>
                    </div>
                    <div>
                        <div class="detail-label">Reorder Level</div>
                        <div class="detail-value"><?php echo $reorder_level; ?> <?php echo htmlspecialchars($material['unit']); ?></div>
                    </div>
                </div>
                
                <div style="margin-top: 15px;">
                    <div class="detail-label">Stock Level Visualization</div>
                    <div style="height: 20px; background: #e5e7eb; border-radius: 10px; margin: 10px 0; position: relative;">
                        <div style="position: absolute; left: 0; width: 100%; height: 100%; display: flex; align-items: center; justify-content: space-between; padding: 0 10px;">
                            <span style="font-size: 0.7rem; color: #ef4444;">Reorder: <?php echo $reorder_level; ?></span>
                            <span style="font-size: 0.7rem; color: #f59e0b;">Min: <?php echo $min_stock; ?></span>
                        </div>
                        <div style="height: 100%; width: <?php echo min(100, ($quantity / max(1, $min_stock * 1.5)) * 100); ?>%; background: linear-gradient(90deg, #10b981, #059669); border-radius: 10px; position: relative;">
                            <div style="position: absolute; right: -10px; top: -5px; width: 30px; height: 30px; background: #667eea; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 0.8rem;">
                                <?php echo $quantity; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- System Information -->
            <div class="detail-card">
                <h3 style="margin-bottom: 20px; color: #1e40af;">🖥️ System Information</h3>
                <div class="detail-row">
                    <div>
                        <div class="detail-label">Material Status</div>
                        <div class="detail-value">
                            <span style="color: <?php echo $material['status'] == 'available' ? '#10b981' : '#ef4444'; ?>; font-weight: 600;">
                                <?php echo ucfirst($material['status']); ?>
                            </span>
                        </div>
                    </div>
                    <div>
                        <div class="detail-label">Created On</div>
                        <div class="detail-value"><?php echo date('F j, Y', strtotime($material['created_at'])); ?></div>
                    </div>
                </div>
                
                <div class="detail-row">
                    <div>
                        <div class="detail-label">Last Updated</div>
                        <div class="detail-value"><?php echo date('F j, Y H:i', strtotime($material['updated_at'])); ?></div>
                    </div>
                    <div>
                        <div class="detail-label">Material ID</div>
                        <div class="detail-value">#<?php echo $material['material_id']; ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="btn-group">
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Inventory
            </a>
            <?php if (in_array($_SESSION['role'], ['admin', 'foreman'])): ?>
                <a href="edit_material.php?id=<?php echo $id; ?>" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Edit Material
                </a>
            <?php endif; ?>
            <?php if ($_SESSION['role'] === 'client'): ?>
                <a href="request_quotation.php?material_id=<?php echo $id; ?>" class="btn btn-primary">
                    <i class="fas fa-file-invoice-dollar"></i> Request Quote
                </a>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add animation to stock visualization
        const stockBar = document.querySelector('div[style*="linear-gradient(90deg, #10b981"]');
        if (stockBar) {
            const width = stockBar.style.width;
            stockBar.style.width = '0%';
            setTimeout(() => {
                stockBar.style.transition = 'width 1.5s ease';
                stockBar.style.width = width;
            }, 300);
        }
    });
    </script>
</body>
</html>
<?php
// Only start session if one is not already active
if (php_sapi_name() !== 'cli' && session_status() === PHP_SESSION_NONE) {
    session_start();
}
ob_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "arcreate_inventory";

$conn = new mysqli($servername, $username, $password);

// Create database if it doesn't exist
if (!$conn->connect_error) {
    $conn->query("CREATE DATABASE IF NOT EXISTS $database CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $conn->select_db($database);
    
    // Set UTF-8
    $conn->set_charset("utf8mb4");
    
    // Enable error reporting in development
    if ($_SERVER['SERVER_NAME'] === 'localhost' || $_SERVER['SERVER_NAME'] === '127.0.0.1') {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    }
} else {
    die(json_encode([
        'status' => 'error',
        'message' => 'Database connection failed: ' . $conn->connect_error,
        'action' => 'Please run database_setup.php first'
    ]));
}
?>
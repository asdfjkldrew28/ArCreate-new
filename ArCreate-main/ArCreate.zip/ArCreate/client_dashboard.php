<?php
// client_dashboard.php - Client Dashboard
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'client') {
    header('Location: login.php');
    exit;
}

include 'db_connect.php';
include 'config.php';

$user_id = $_SESSION['user_id'];

// First, create client record if it doesn't exist
$check_client = $conn->query("SELECT * FROM clients WHERE user_id = $user_id");
if ($check_client->num_rows == 0) {
    // Create client record from user info
    $full_name = $_SESSION['full_name'];
    $email = $conn->query("SELECT email FROM users WHERE user_id = $user_id")->fetch_assoc()['email'];
    
    $conn->query("INSERT INTO clients (user_id, client_name, email, status) VALUES ($user_id, '$full_name', '$email', 'active')");
}

// Get client info
$client_info = $conn->query("
    SELECT c.*, u.email, u.phone
    FROM clients c 
    JOIN users u ON c.user_id = u.user_id 
    WHERE u.user_id = $user_id
")->fetch_assoc();

$client_id = $client_info['client_id'];

// Client Statistics - simplified for demo
$total_projects = $conn->query("SELECT COUNT(*) as count FROM projects WHERE client_id = $client_id")->fetch_assoc()['count'];
$active_projects = $conn->query("SELECT COUNT(*) as count FROM projects WHERE client_id = $client_id AND status NOT IN ('completed', 'cancelled')")->fetch_assoc()['count'];
$total_investment = $conn->query("SELECT COALESCE(SUM(total_contract_amount), 0) as total FROM projects WHERE client_id = $client_id")->fetch_assoc()['total'];
$paid_amount = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM payments p JOIN projects pr ON p.project_id = pr.project_id WHERE pr.client_id = $client_id")->fetch_assoc()['total'];

// My Projects
$projects = $conn->query("
    SELECT p.*, u.full_name as project_manager
    FROM projects p 
    LEFT JOIN users u ON p.project_manager_id = u.user_id
    WHERE p.client_id = $client_id 
    ORDER BY p.status, p.start_date DESC
    LIMIT 5
");

// Recent Payments
$recent_payments = $conn->query("
    SELECT p.*, pr.project_name
    FROM payments p
    JOIN projects pr ON p.project_id = pr.project_id
    WHERE pr.client_id = $client_id
    ORDER BY p.payment_date DESC
    LIMIT 5
");

// Recent Progress Updates
$recent_updates = $conn->query("
    SELECT pp.*, pr.project_name, u.full_name as reported_by
    FROM project_progress pp
    JOIN projects pr ON pp.project_id = pr.project_id
    LEFT JOIN users u ON pp.reported_by = u.user_id
    WHERE pr.client_id = $client_id
    ORDER BY pp.progress_date DESC
    LIMIT 5
");

// Project Managers assigned to my projects
$project_team = $conn->query("
    SELECT DISTINCT u.user_id, u.full_name, u.role, u.email, u.phone
    FROM users u
    JOIN projects p ON u.user_id = p.project_manager_id
    WHERE p.client_id = $client_id 
    AND u.status = 'active'
    ORDER BY u.role
    LIMIT 6
");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Projects - ArCreate</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            min-height: 100vh;
        }
        
        .dashboard-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            background: linear-gradient(180deg, #4b5563 0%, #374151 100%);
            color: white;
            padding: 30px 20px;
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .logo img {
            max-height: 60px;
            margin-bottom: 10px;
        }
        
        .logo h2 {
            color: white;
            font-size: 1.5rem;
        }
        
        .user-info {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 2rem;
            color: white;
            font-weight: bold;
        }
        
        .user-name {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .user-role {
            color: #cbd5e1;
            font-size: 0.9rem;
            background: rgba(107, 114, 128, 0.2);
            padding: 4px 12px;
            border-radius: 15px;
            display: inline-block;
        }
        
        .nav-menu {
            list-style: none;
            margin-bottom: 30px;
        }
        
        .nav-item {
            margin-bottom: 10px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            color: #cbd5e1;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .nav-link:hover, .nav-link.active {
            background: rgba(102, 126, 234, 0.2);
            color: white;
        }
        
        .nav-link i {
            width: 20px;
            text-align: center;
        }
        
        /* Main Content Styles */
        .main-content {
            padding: 30px;
            overflow-y: auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .header h1 {
            color: #1e293b;
            font-size: 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            border: 1px solid #e5e7eb;
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-bottom: 15px;
        }
        
        .stat-icon.projects { background: linear-gradient(135deg, #667eea, #764ba2); }
        .stat-icon.active { background: linear-gradient(135deg, #10b981, #059669); }
        .stat-icon.investment { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .stat-icon.paid { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
        
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #1e293b;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #64748b;
            font-size: 0.9rem;
        }
        
        .dashboard-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            border: 1px solid #e5e7eb;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .section-header h3 {
            color: #1e293b;
            font-size: 1.3rem;
        }
        
        .project-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            border: 2px solid #e5e7eb;
            transition: all 0.3s;
        }
        
        .project-card:hover {
            border-color: #6b7280;
            transform: translateY(-3px);
        }
        
        .project-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .project-status {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-planning { background: #f3f4f6; color: #4b5563; }
        .status-design { background: #dbeafe; color: #1e40af; }
        .status-construction { background: #fef3c7; color: #92400e; }
        .status-finishing { background: #fce7f3; color: #9d174d; }
        .status-completed { background: #dcfce7; color: #166534; }
        
        .team-card {
            background: #f8fafc;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
        }
        
        .payment-card {
            background: #f0f9ff;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
            border-left: 4px solid #3b82f6;
        }
        
        .progress-card {
            background: #f0fdf4;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
            border-left: 4px solid #10b981;
        }
        
        .progress-bar {
            height: 8px;
            background: #e5e7eb;
            border-radius: 4px;
            margin: 10px 0;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #10b981, #059669);
            border-radius: 4px;
        }
        
        .contact-info {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 5px;
        }
        
        .logout-btn {
            margin-top: auto;
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            border: none;
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .logout-btn:hover {
            background: rgba(239, 68, 68, 0.2);
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-secondary {
            background: #f3f4f6;
            color: #4b5563;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <?php if (defined('SITE_LOGO') && file_exists(SITE_LOGO)): ?>
                    <img src="<?php echo SITE_LOGO; ?>" alt="ArCreate Logo">
                <?php else: ?>
                    <div style="font-size: 2.5rem; margin-bottom: 10px;">👤</div>
                <?php endif; ?>
                <h2>ArCreate</h2>
            </div>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?>
                </div>
                <div class="user-name"><?php echo htmlspecialchars($_SESSION['full_name']); ?></div>
                <div class="user-role">Client</div>
                <div style="font-size: 0.8rem; color: #cbd5e1; margin-top: 5px;">
                    <?php echo $client_info['company'] ?? 'Individual Client'; ?>
                </div>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="client_dashboard.php" class="nav-link active">
                        <i class="fas fa-tachometer-alt"></i>
                        My Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="my_projects.php" class="nav-link">
                        <i class="fas fa-project-diagram"></i>
                        My Projects
                    </a>
                </li>
                <li class="nav-item">
                    <a href="project_progress.php" class="nav-link">
                        <i class="fas fa-chart-line"></i>
                        Progress Updates
                    </a>
                </li>
                <li class="nav-item">
                    <a href="payments.php" class="nav-link">
                        <i class="fas fa-credit-card"></i>
                        Payments
                    </a>
                </li>
                <li class="nav-item">
                    <a href="invoices.php" class="nav-link">
                        <i class="fas fa-file-invoice"></i>
                        Invoices
                    </a>
                </li>
                <li class="nav-item">
                    <a href="project_team.php" class="nav-link">
                        <i class="fas fa-users"></i>
                        Project Team
                    </a>
                </li>
                <li class="nav-item">
                    <a href="messages.php" class="nav-link">
                        <i class="fas fa-envelope"></i>
                        Messages
                    </a>
                </li>
                <li class="nav-item">
                    <a href="profile.php" class="nav-link">
                        <i class="fas fa-user-cog"></i>
                        Profile Settings
                    </a>
                </li>
            </ul>
            
            <button class="logout-btn" onclick="logout()">
                <i class="fas fa-sign-out-alt"></i> Logout
            </button>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div>
                    <h1>My Projects Dashboard</h1>
                    <p style="color: #64748b;">Track your construction projects and investments</p>
                </div>
                <div style="color: #64748b;">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('F j, Y'); ?>
                </div>
            </div>
            
            <!-- Client Welcome -->
            <div class="dashboard-section" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
                <div style="display: flex; align-items: center; gap: 20px;">
                    <div style="font-size: 3rem;">
                        <i class="fas fa-handshake"></i>
                    </div>
                    <div>
                        <h2 style="color: white; margin-bottom: 5px;">Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h2>
                        <p style="opacity: 0.9;">Thank you for choosing ArCreate for your construction needs.</p>
                        <div style="display: flex; gap: 20px; margin-top: 10px;">
                            <div>
                                <i class="fas fa-phone"></i> <?php echo $client_info['phone'] ?? 'Not provided'; ?>
                            </div>
                            <div>
                                <i class="fas fa-envelope"></i> <?php echo $client_info['email'] ?? 'Not provided'; ?>
                            </div>
                            <div>
                                <i class="fas fa-building"></i> <?php echo $client_info['client_type'] ?? 'individual'; ?> Client
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon projects">
                        <i class="fas fa-project-diagram"></i>
                    </div>
                    <div class="stat-value"><?php echo $total_projects; ?></div>
                    <div class="stat-label">Total Projects</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon active">
                        <i class="fas fa-hard-hat"></i>
                    </div>
                    <div class="stat-value"><?php echo $active_projects; ?></div>
                    <div class="stat-label">Active Projects</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon investment">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="stat-value">₱<?php echo number_format($total_investment, 2); ?></div>
                    <div class="stat-label">Total Investment</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon paid">
                        <i class="fas fa-wallet"></i>
                    </div>
                    <div class="stat-value">₱<?php echo number_format($paid_amount, 2); ?></div>
                    <div class="stat-label">Amount Paid</div>
                </div>
            </div>
            
            <!-- Two Column Layout -->
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px;">
                <!-- Left Column -->
                <div>
                    <!-- My Projects -->
                    <div class="dashboard-section">
                        <div class="section-header">
                            <h3><i class="fas fa-list"></i> My Projects</h3>
                            <a href="my_projects.php" style="color: #667eea; text-decoration: none;">View All →</a>
                        </div>
                        <?php if ($projects && $projects->num_rows > 0): ?>
                            <?php while($project = $projects->fetch_assoc()): 
                                $balance = $project['balance'] ?? 0;
                            ?>
                            <div class="project-card">
                                <div class="project-header">
                                    <div>
                                        <h4 style="color: #1e293b; margin-bottom: 5px;">
                                            <?php echo htmlspecialchars($project['project_name']); ?>
                                        </h4>
                                        <div style="font-size: 0.9rem; color: #64748b;">
                                            <?php echo $project['project_type'] ?? 'Residential'; ?> • 
                                            <?php echo $project['address'] ?? 'Address not specified'; ?>
                                        </div>
                                    </div>
                                    <span class="project-status status-<?php echo $project['status']; ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $project['status'])); ?>
                                    </span>
                                </div>
                                
                                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 15px;">
                                    <div>
                                        <div style="font-size: 0.9rem; color: #64748b; margin-bottom: 5px;">
                                            <strong>Project Manager:</strong> <?php echo htmlspecialchars($project['project_manager'] ?? 'Not assigned'); ?>
                                        </div>
                                        <div style="font-size: 0.9rem; color: #64748b;">
                                            <strong>Start Date:</strong> <?php echo $project['start_date'] ? date('M d, Y', strtotime($project['start_date'])) : 'Not set'; ?>
                                        </div>
                                    </div>
                                    <div>
                                        <div style="font-size: 0.9rem; color: #64748b; margin-bottom: 5px;">
                                            <strong>Contract Amount:</strong> ₱<?php echo number_format($project['total_contract_amount'], 2); ?>
                                        </div>
                                        <div style="font-size: 0.9rem; color: <?php echo $balance > 0 ? '#ef4444' : '#10b981'; ?>; font-weight: 600;">
                                            <strong>Balance:</strong> ₱<?php echo number_format($balance, 2); ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div style="display: flex; gap: 10px; margin-top: 15px;">
                                    <a href="view_project.php?id=<?php echo $project['project_id']; ?>" class="btn btn-primary">
                                        <i class="fas fa-eye"></i> View Details
                                    </a>
                                    <a href="project_progress.php?id=<?php echo $project['project_id']; ?>" class="btn btn-secondary">
                                        <i class="fas fa-chart-line"></i> Progress
                                    </a>
                                    <a href="make_payment.php?project_id=<?php echo $project['project_id']; ?>" class="btn btn-success">
                                        <i class="fas fa-credit-card"></i> Make Payment
                                    </a>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div style="text-align: center; padding: 40px; color: #64748b;">
                                <div style="font-size: 3rem; margin-bottom: 20px;">🏗️</div>
                                <h3>No Projects Yet</h3>
                                <p>You don't have any construction projects yet.</p>
                                <a href="request_quotation.php" class="btn btn-primary" style="margin-top: 15px;">
                                    <i class="fas fa-file-invoice-dollar"></i> Request a Quotation
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Right Column -->
                <div>
                    <!-- Project Team -->
                    <div class="dashboard-section">
                        <h3 style="margin-bottom: 20px;"><i class="fas fa-users"></i> Project Team</h3>
                        <?php if ($project_team && $project_team->num_rows > 0): ?>
                            <div style="max-height: 300px; overflow-y: auto;">
                                <?php while($member = $project_team->fetch_assoc()): ?>
                                <div class="team-card">
                                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                                        <div style="width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #6b7280, #4b5563); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                            <?php echo strtoupper(substr($member['full_name'], 0, 1)); ?>
                                        </div>
                                        <div>
                                            <div style="font-weight: 600;"><?php echo htmlspecialchars($member['full_name']); ?></div>
                                            <div style="font-size: 0.8rem; color: #64748b;">
                                                <?php echo ucfirst(str_replace('_', ' ', $member['role'])); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="contact-info">
                                        <?php if ($member['email']): ?>
                                            <a href="mailto:<?php echo $member['email']; ?>" style="color: #667eea;">
                                                <i class="fas fa-envelope"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if ($member['phone']): ?>
                                            <a href="tel:<?php echo $member['phone']; ?>" style="color: #10b981;">
                                                <i class="fas fa-phone"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div style="text-align: center; padding: 20px; color: #64748b;">
                                <div style="font-size: 2rem; margin-bottom: 10px;">👥</div>
                                <p>No team members assigned yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Recent Payments -->
                    <div class="dashboard-section">
                        <h3 style="margin-bottom: 20px;"><i class="fas fa-credit-card"></i> Recent Payments</h3>
                        <?php if ($recent_payments && $recent_payments->num_rows > 0): ?>
                            <div style="max-height: 250px; overflow-y: auto;">
                                <?php while($payment = $recent_payments->fetch_assoc()): ?>
                                <div class="payment-card">
                                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                        <div style="font-weight: 600;"><?php echo htmlspecialchars($payment['project_name']); ?></div>
                                        <div style="color: #10b981; font-weight: 600;">
                                            ₱<?php echo number_format($payment['amount'], 2); ?>
                                        </div>
                                    </div>
                                    <div style="font-size: 0.8rem; color: #6b7280; margin-bottom: 5px;">
                                        <?php echo ucfirst(str_replace('_', ' ', $payment['payment_type'])); ?>
                                    </div>
                                    <div style="font-size: 0.7rem; color: #9ca3af;">
                                        <?php echo date('M d, Y', strtotime($payment['payment_date'])); ?> • 
                                        <?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </div>
                            <a href="payments.php" class="btn btn-primary" style="width: 100%; margin-top: 15px; text-align: center;">
                                <i class="fas fa-history"></i> Payment History
                            </a>
                        <?php else: ?>
                            <div style="text-align: center; padding: 20px; color: #64748b;">
                                <div style="font-size: 2rem; margin-bottom: 10px;">💳</div>
                                <p>No payments made yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Recent Progress -->
                    <div class="dashboard-section">
                        <h3 style="margin-bottom: 20px;"><i class="fas fa-chart-line"></i> Recent Updates</h3>
                        <?php if ($recent_updates && $recent_updates->num_rows > 0): ?>
                            <div style="max-height: 250px; overflow-y: auto;">
                                <?php while($update = $recent_updates->fetch_assoc()): ?>
                                <div class="progress-card">
                                    <div style="font-weight: 600; margin-bottom: 5px;">
                                        <?php echo htmlspecialchars($update['project_name']); ?>
                                    </div>
                                    <div style="font-size: 0.9rem; color: #4b5563; margin-bottom: 5px;">
                                        <strong><?php echo $update['phase']; ?></strong> - <?php echo $update['percentage']; ?>%
                                    </div>
                                    <div style="font-size: 0.8rem; color: #6b7280;">
                                        <?php echo htmlspecialchars(substr($update['description'], 0, 80)); ?>...
                                    </div>
                                    <div style="font-size: 0.7rem; color: #9ca3af; margin-top: 5px;">
                                        <?php echo date('M d', strtotime($update['progress_date'])); ?> • 
                                        By: <?php echo htmlspecialchars($update['reported_by']); ?>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </div>
                            <a href="project_progress.php" class="btn btn-success" style="width: 100%; margin-top: 15px; text-align: center;">
                                <i class="fas fa-list"></i> All Updates
                            </a>
                        <?php else: ?>
                            <div style="text-align: center; padding: 20px; color: #64748b;">
                                <div style="font-size: 2rem; margin-bottom: 10px;">📈</div>
                                <p>No progress updates yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="dashboard-section">
                        <h3 style="margin-bottom: 20px;"><i class="fas fa-bolt"></i> Quick Actions</h3>
                        <div style="display: grid; gap: 10px;">
                            <a href="request_quotation.php" class="btn btn-primary">
                                <i class="fas fa-file-invoice"></i> Request Quote
                            </a>
                            <a href="send_message.php" class="btn btn-secondary">
                                <i class="fas fa-envelope"></i> Send Message
                            </a>
                            <a href="schedule_meeting.php" class="btn btn-warning">
                                <i class="fas fa-calendar-plus"></i> Schedule Meeting
                            </a>
                            <a href="view_invoices.php" class="btn btn-success">
                                <i class="fas fa-file-invoice-dollar"></i> View Invoices
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function logout() {
        Swal.fire({
            title: 'Logout?',
            text: 'Are you sure you want to logout?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#667eea',
            cancelButtonColor: '#6b7280',
            confirmButtonText: 'Yes, Logout'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'logout.php';
            }
        });
    }
    
    // Auto-check for new updates every 2 minutes
    setTimeout(() => {
        location.reload();
    }, 120000);
    </script>
</body>
</html>
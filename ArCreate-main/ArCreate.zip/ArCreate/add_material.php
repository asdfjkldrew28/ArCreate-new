<?php
// add_material.php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'foreman'])) {
    header('Location: login.php');
    exit;
}

include 'db_connect.php';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $material_name = $conn->real_escape_string($_POST['material_name']);
        $category = $conn->real_escape_string($_POST['category']);
        $description = $conn->real_escape_string($_POST['description']);
        $quantity = (int)$_POST['quantity'];
        $unit = $conn->real_escape_string($_POST['unit']);
        $unit_price = floatval($_POST['unit_price']);
        $location = $conn->real_escape_string($_POST['location']);
        $supplier_id = !empty($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : NULL;
        $min_stock_level = (int)$_POST['min_stock_level'];
        $reorder_level = (int)$_POST['reorder_level'];
        
        $stmt = $conn->prepare("INSERT INTO materials (material_name, category, description, quantity, unit, unit_price, location, supplier_id, min_stock_level, reorder_level) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssisdsiii", $material_name, $category, $description, $quantity, $unit, $unit_price, $location, $supplier_id, $min_stock_level, $reorder_level);
        
        if ($stmt->execute()) {
            $success = true;
            // Log the change
            $log_query = "INSERT INTO change_logs (username, action, table_name, record_id, changes) VALUES (?, 'INSERT', 'materials', ?, ?)";
            $log_stmt = $conn->prepare($log_query);
            $changes = json_encode([
                'material_name' => $material_name,
                'category' => $category,
                'quantity' => $quantity
            ]);
            $record_id = $conn->insert_id;
            $log_stmt->bind_param("sis", $_SESSION['username'], $record_id, $changes);
            $log_stmt->execute();
        } else {
            $error = "Failed to add material: " . $conn->error;
        }
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Fetch suppliers for dropdown
$suppliers = $conn->query("SELECT supplier_id, supplier_name FROM suppliers WHERE status='active' ORDER BY supplier_name");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Add New Material - ArCreate</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #1e40af;
            font-size: 2rem;
        }
        
        .header-icon {
            font-size: 2rem;
            color: #667eea;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .required::after {
            content: " *";
            color: #ef4444;
        }
        
        input, select, textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-secondary {
            background: #f3f4f6;
            color: #4b5563;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .stock-level-info {
            background: #f8fafc;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid #667eea;
        }
        
        .stock-level-info h4 {
            color: #1e40af;
            margin-bottom: 10px;
        }
        
        .stock-level-info ul {
            padding-left: 20px;
            color: #6b7280;
        }
        
        .stock-level-info li {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="header-icon">
                <i class="fas fa-plus-circle"></i>
            </div>
            <div>
                <h1>Add New Construction Material</h1>
                <p style="color: #6b7280;">Register new materials for inventory tracking</p>
            </div>
        </div>
        
        <?php if ($error): ?>
        <div id="errorAlert" style="display: none;"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
        <div id="successAlert" style="display: none;">Material added successfully!</div>
        <?php endif; ?>
        
        <div class="stock-level-info">
            <h4>📊 Stock Level Guidelines:</h4>
            <ul>
                <li><strong>Minimum Stock Level:</strong> When stock reaches this level, it will show as "Low Stock"</li>
                <li><strong>Reorder Level:</strong> When stock reaches this level, it will trigger critical alerts</li>
                <li>Recommended: Set Reorder Level lower than Minimum Stock Level</li>
            </ul>
        </div>
        
        <form method="post" id="addMaterialForm">
            <div class="form-group">
                <label for="material_name" class="required">Material Name</label>
                <input type="text" id="material_name" name="material_name" required placeholder="e.g., Cement, Steel Bars, PVC Pipes">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="category" class="required">Category</label>
                    <select id="category" name="category" required>
                        <option value="">Select Category</option>
                        <option value="construction">🏗️ Construction</option>
                        <option value="hardware">🔧 Hardware</option>
                        <option value="electrical">⚡ Electrical</option>
                        <option value="plumbing">🚰 Plumbing</option>
                        <option value="finishing">🎨 Finishing</option>
                        <option value="tools">🛠️ Tools</option>
                        <option value="safety">🦺 Safety</option>
                        <option value="office">📁 Office</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="quantity" class="required">Initial Quantity</label>
                    <input type="number" id="quantity" name="quantity" required min="0" placeholder="0">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="unit" class="required">Unit</label>
                    <select id="unit" name="unit" required>
                        <option value="pcs">Pieces (pcs)</option>
                        <option value="bags">Bags</option>
                        <option value="kg">Kilograms (kg)</option>
                        <option value="m">Meters (m)</option>
                        <option value="roll">Rolls</option>
                        <option value="set">Sets</option>
                        <option value="box">Boxes</option>
                        <option value="liter">Liters</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="unit_price" class="required">Unit Price (₱)</label>
                    <input type="number" id="unit_price" name="unit_price" required step="0.01" min="0" placeholder="0.00">
                </div>
            </div>
            
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="3" placeholder="Material specifications, brand, grade, etc."></textarea>
            </div>
            
            <div class="form-group">
                <label for="location">Storage Location</label>
                <input type="text" id="location" name="location" placeholder="e.g., Warehouse A, Shelf 3">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="supplier_id">Supplier</label>
                    <select id="supplier_id" name="supplier_id">
                        <option value="">Select Supplier</option>
                        <?php while($supplier = $suppliers->fetch_assoc()): ?>
                        <option value="<?php echo $supplier['supplier_id']; ?>"><?php echo htmlspecialchars($supplier['supplier_name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="min_stock_level">Minimum Stock Level</label>
                    <input type="number" id="min_stock_level" name="min_stock_level" min="1" value="10">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="reorder_level">Reorder Level</label>
                    <input type="number" id="reorder_level" name="reorder_level" min="0" value="5">
                </div>
            </div>
            
            <div class="btn-group">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Save Material
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancel
                </a>
            </div>
        </form>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const successAlert = document.getElementById('successAlert');
        const errorAlert = document.getElementById('errorAlert');
        
        if (successAlert) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: successAlert.textContent,
                confirmButtonColor: '#667eea',
                timer: 3000,
                timerProgressBar: true
            }).then(() => {
                window.location.href = 'index.php';
            });
        }
        
        if (errorAlert) {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: errorAlert.textContent,
                confirmButtonColor: '#ef4444'
            });
        }
        
        // Form validation
        const form = document.getElementById('addMaterialForm');
        form.addEventListener('submit', function(e) {
            const unitPrice = document.getElementById('unit_price').value;
            const quantity = document.getElementById('quantity').value;
            
            if (parseFloat(unitPrice) <= 0) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Price',
                    text: 'Unit price must be greater than 0',
                    confirmButtonColor: '#f59e0b'
                });
                return false;
            }
            
            if (parseInt(quantity) < 0) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Quantity',
                    text: 'Quantity cannot be negative',
                    confirmButtonColor: '#f59e0b'
                });
                return false;
            }
            
            return true;
        });
    });
    </script>
</body>
</html>
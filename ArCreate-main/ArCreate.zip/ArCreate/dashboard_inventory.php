<?php
// dashboard_inventory.php - Inventory Dashboard for ArCreate
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'project_manager', 'site_engineer'])) { 
    header('Location: login.php'); 
    exit; 
}
include 'db_connect.php';

// Inventory Statistics
$total_items = $conn->query("SELECT COUNT(*) as count FROM materials")->fetch_assoc()['count'];
$total_value = $conn->query("SELECT COALESCE(SUM(quantity * unit_price), 0) as total FROM materials")->fetch_assoc()['total'];
$low_stock = $conn->query("SELECT COUNT(*) as count FROM materials WHERE quantity <= min_stock_level")->fetch_assoc()['count'];
$out_of_stock = $conn->query("SELECT COUNT(*) as count FROM materials WHERE quantity = 0")->fetch_assoc()['count'];

// Recent stock movements
$recent_stock_in = $conn->query("
    SELECT si.*, m.material_name, s.supplier_name
    FROM stock_in si
    LEFT JOIN materials m ON si.material_id = m.material_id
    LEFT JOIN suppliers s ON si.supplier_id = s.supplier_id
    ORDER BY si.date_received DESC
    LIMIT 5
");

$recent_stock_out = $conn->query("
    SELECT so.*, m.material_name, p.project_name
    FROM stock_out so
    LEFT JOIN materials m ON so.material_id = m.material_id
    LEFT JOIN projects p ON so.project_id = p.project_id
    ORDER BY so.date_issued DESC
    LIMIT 5
");

// Category breakdown
$categories = $conn->query("
    SELECT category, COUNT(*) as item_count, SUM(quantity * unit_price) as total_value
    FROM materials
    GROUP BY category
    ORDER BY total_value DESC
");

// Low stock items
$low_stock_items = $conn->query("
    SELECT * FROM materials 
    WHERE quantity <= min_stock_level
    ORDER BY quantity ASC
    LIMIT 5
");

// Top suppliers
$top_suppliers = $conn->query("
    SELECT s.supplier_name, COUNT(m.material_id) as item_count, 
           SUM(m.quantity * m.unit_price) as total_value
    FROM suppliers s
    LEFT JOIN materials m ON s.supplier_id = m.supplier_id
    GROUP BY s.supplier_id
    ORDER BY total_value DESC
    LIMIT 5
");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Inventory Dashboard - ArCreate</title>
<style>
.inventory-container {
    background: white;
    border-radius: 15px;
    padding: 30px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 25px;
    margin-bottom: 30px;
}

.stat-card {
    background: #f8fafc;
    padding: 25px;
    border-radius: 15px;
    text-align: center;
    border: 2px solid #e5e7eb;
    transition: all 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
    border-color: #667eea;
}

.stat-value {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 10px;
}

.stat-card.total .stat-value { color: #667eea; }
.stat-card.value .stat-value { color: #10b981; }
.stat-card.low .stat-value { color: #f59e0b; }
.stat-card.out .stat-value { color: #ef4444; }

.stat-label {
    color: #6b7280;
    font-size: 1rem;
    font-weight: 600;
}

.dashboard-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 25px;
    margin-bottom: 30px;
}

.stock-movement {
    background: white;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 15px;
    border: 1px solid #e5e7eb;
    transition: all 0.3s;
}

.stock-movement:hover {
    border-color: #667eea;
    transform: translateX(5px);
}

.movement-in {
    border-left: 4px solid #10b981;
}

.movement-out {
    border-left: 4px solid #ef4444;
}

.category-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    margin-bottom: 10px;
    background: #f8fafc;
    border-radius: 10px;
    border: 1px solid #e5e7eb;
}

.category-bar {
    height: 8px;
    background: #667eea;
    border-radius: 4px;
    margin-top: 5px;
}

.supplier-card {
    background: white;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 15px;
    border: 2px solid #e5e7eb;
}

.alert-card {
    background: #fef3c7;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 15px;
    border: 2px solid #f59e0b;
}

.alert-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 15px;
    margin-top: 30px;
}

.action-btn {
    background: white;
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    border: 2px solid #e5e7eb;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    color: #333;
}

.action-btn:hover {
    border-color: #667eea;
    transform: translateY(-3px);
}

.action-icon {
    font-size: 2rem;
    margin-bottom: 10px;
    color: #667eea;
}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>📦 Inventory Dashboard</h1>
        <p>Construction materials management and tracking</p>
    </div>
    
    <div class="inventory-container">
        <!-- Inventory Statistics -->
        <div class="stats-grid">
            <div class="stat-card total">
                <div class="stat-value"><?php echo $total_items; ?></div>
                <div class="stat-label">Total Items</div>
                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 10px;">
                    Across all categories
                </div>
            </div>
            
            <div class="stat-card value">
                <div class="stat-value">₱<?php echo number_format($total_value, 2); ?></div>
                <div class="stat-label">Total Value</div>
                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 10px;">
                    Current inventory worth
                </div>
            </div>
            
            <div class="stat-card low">
                <div class="stat-value"><?php echo $low_stock; ?></div>
                <div class="stat-label">Low Stock Items</div>
                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 10px;">
                    Below minimum level
                </div>
            </div>
            
            <div class="stat-card out">
                <div class="stat-value"><?php echo $out_of_stock; ?></div>
                <div class="stat-label">Out of Stock</div>
                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 10px;">
                    Needs immediate attention
                </div>
            </div>
        </div>
        
        <div class="dashboard-grid">
            <!-- Left Column -->
            <div>
                <!-- Recent Stock Movements -->
                <h3>📤 Recent Stock Movements</h3>
                
                <h4 style="margin-top: 20px; color: #10b981;">⬆️ Stock In</h4>
                <?php if($recent_stock_in && $recent_stock_in->num_rows > 0): ?>
                    <?php while($stock_in = $recent_stock_in->fetch_assoc()): ?>
                    <div class="stock-movement movement-in">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <div style="font-weight: 600; color: #333;">
                                    <?php echo htmlspecialchars($stock_in['material_name']); ?>
                                </div>
                                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 5px;">
                                    Supplier: <?php echo htmlspecialchars($stock_in['supplier_name'] ?: 'Unknown'); ?>
                                </div>
                                <div style="font-size: 0.8rem; color: #9ca3af; margin-top: 5px;">
                                    <?php echo date('M d, g:i A', strtotime($stock_in['date_received'])); ?>
                                </div>
                            </div>
                            <div style="text-align: right;">
                                <div style="font-weight: bold; color: #10b981; font-size: 1.2rem;">
                                    +<?php echo $stock_in['quantity']; ?>
                                </div>
                                <div style="font-size: 0.9rem; color: #6b7280;">
                                    ₱<?php echo number_format($stock_in['quantity'] * ($stock_in['unit_price'] ?? 0), 2); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="text-align: center; padding: 30px; color: #666; background: #f8fafc; border-radius: 10px;">
                        <div style="font-size: 2rem; margin-bottom: 10px;">📥</div>
                        <p>No recent stock in records</p>
                    </div>
                <?php endif; ?>
                
                <h4 style="margin-top: 30px; color: #ef4444;">⬇️ Stock Out</h4>
                <?php if($recent_stock_out && $recent_stock_out->num_rows > 0): ?>
                    <?php while($stock_out = $recent_stock_out->fetch_assoc()): ?>
                    <div class="stock-movement movement-out">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <div style="font-weight: 600; color: #333;">
                                    <?php echo htmlspecialchars($stock_out['material_name']); ?>
                                </div>
                                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 5px;">
                                    Project: <?php echo htmlspecialchars($stock_out['project_name'] ?: 'General Use'); ?>
                                </div>
                                <div style="font-size: 0.8rem; color: #9ca3af; margin-top: 5px;">
                                    <?php echo date('M d, g:i A', strtotime($stock_out['date_issued'])); ?>
                                </div>
                                <?php if($stock_out['purpose']): ?>
                                <div style="font-size: 0.8rem; color: #6b7280; margin-top: 5px; font-style: italic;">
                                    Purpose: <?php echo htmlspecialchars($stock_out['purpose']); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div style="text-align: right;">
                                <div style="font-weight: bold; color: #ef4444; font-size: 1.2rem;">
                                    -<?php echo $stock_out['quantity']; ?>
                                </div>
                                <div style="font-size: 0.9rem; color: #6b7280;">
                                    Issued for project
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="text-align: center; padding: 30px; color: #666; background: #f8fafc; border-radius: 10px;">
                        <div style="font-size: 2rem; margin-bottom: 10px;">📤</div>
                        <p>No recent stock out records</p>
                    </div>
                <?php endif; ?>
                
                <!-- Category Breakdown -->
                <h3 style="margin-top: 30px;">📊 Category Breakdown</h3>
                <?php if($categories && $categories->num_rows > 0): 
                    $maxValue = 0;
                    $catData = [];
                    while($cat = $categories->fetch_assoc()) {
                        $catData[] = $cat;
                        if ($cat['total_value'] > $maxValue) $maxValue = $cat['total_value'];
                    }
                    
                    foreach($catData as $cat):
                        $percentage = $maxValue > 0 ? ($cat['total_value'] / $maxValue) * 100 : 0;
                        $categoryIcons = [
                            'construction' => '🏗️',
                            'hardware' => '🔧',
                            'electrical' => '⚡',
                            'plumbing' => '🚰',
                            'finishing' => '🎨',
                            'tools' => '🛠️',
                            'safety' => '🦺',
                            'office' => '📁'
                        ];
                ?>
                <div class="category-item">
                    <div style="flex: 1;">
                        <div style="font-weight: 600; color: #333;">
                            <?php echo $categoryIcons[$cat['category']] ?? '📦'; ?>
                            <?php echo ucfirst($cat['category']); ?>
                        </div>
                        <div style="font-size: 0.9rem; color: #6b7280;">
                            <?php echo $cat['item_count']; ?> items
                        </div>
                        <div class="category-bar" style="width: <?php echo $percentage; ?>%;"></div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-weight: bold; color: #1e40af;">
                            ₱<?php echo number_format($cat['total_value'], 2); ?>
                        </div>
                        <div style="font-size: 0.8rem; color: #6b7280;">
                            <?php echo round(($cat['total_value'] / $total_value) * 100, 1); ?>% of total
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <div style="text-align: center; padding: 30px; color: #666; background: #f8fafc; border-radius: 10px;">
                    <div style="font-size: 2rem; margin-bottom: 10px;">📦</div>
                    <p>No inventory categories found</p>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Right Column -->
            <div>
                <!-- Low Stock Alerts -->
                <h3>⚠️ Low Stock Alerts</h3>
                <?php if($low_stock_items && $low_stock_items->num_rows > 0): ?>
                    <?php while($item = $low_stock_items->fetch_assoc()): 
                        $reorder_level = $item['reorder_level'] ?? 5;
                        $min_stock = $item['min_stock_level'] ?? 10;
                        $status = $item['quantity'] == 0 ? 'Out of Stock' : 
                                 ($item['quantity'] <= $reorder_level ? 'Critical' : 'Low');
                        $color = $item['quantity'] == 0 ? '#ef4444' : 
                                ($item['quantity'] <= $reorder_level ? '#f59e0b' : '#fbbf24');
                    ?>
                    <div class="alert-card">
                        <div class="alert-header">
                            <div style="font-weight: 600; color: #333;">
                                <?php echo htmlspecialchars($item['material_name']); ?>
                            </div>
                            <span style="background: <?php echo $color; ?>; 
                                  color: white; padding: 3px 8px; border-radius: 12px; font-size: 0.7rem;">
                                <?php echo $status; ?>
                            </span>
                        </div>
                        <div style="color: #6b7280; font-size: 0.9rem; margin-bottom: 10px;">
                            <?php echo htmlspecialchars($item['location']); ?>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <div style="font-size: 0.9rem; color: #6b7280;">
                                    Current: <span style="font-weight: bold; color: <?php echo $color; ?>;">
                                        <?php echo $item['quantity']; ?> <?php echo $item['unit']; ?>
                                    </span>
                                </div>
                                <div style="font-size: 0.8rem; color: #9ca3af;">
                                    Min: <?php echo $min_stock; ?> • Reorder: <?php echo $reorder_level; ?>
                                </div>
                            </div>
                            <div>
                                <button class="btn" onclick="createPO(<?php echo $item['material_id']; ?>)" 
                                        style="background: #f59e0b; color: white; padding: 5px 10px; font-size: 0.8rem;">
                                    <i class="fas fa-shopping-cart"></i> Order
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="text-align: center; padding: 30px; color: #666; background: #f8fafc; border-radius: 10px;">
                        <div style="font-size: 2rem; margin-bottom: 10px;">✅</div>
                        <p>No low stock alerts</p>
                        <p style="font-size: 0.9rem;">All inventory levels are satisfactory</p>
                    </div>
                <?php endif; ?>
                
                <!-- Top Suppliers -->
                <h3 style="margin-top: 30px;">🏆 Top Suppliers</h3>
                <?php if($top_suppliers && $top_suppliers->num_rows > 0): ?>
                    <?php while($supplier = $top_suppliers->fetch_assoc()): ?>
                    <div class="supplier-card">
                        <div style="font-weight: 600; color: #333; margin-bottom: 10px;">
                            <?php echo htmlspecialchars($supplier['supplier_name']); ?>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <div style="font-size: 0.9rem; color: #6b7280;">
                                    <?php echo $supplier['item_count']; ?> items supplied
                                </div>
                                <div style="font-size: 0.8rem; color: #9ca3af;">
                                    Total value
                                </div>
                            </div>
                            <div style="text-align: right;">
                                <div style="font-weight: bold; color: #1e40af;">
                                    ₱<?php echo number_format($supplier['total_value'] ?? 0, 2); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="text-align: center; padding: 30px; color: #666; background: #f8fafc; border-radius: 10px;">
                        <div style="font-size: 2rem; margin-bottom: 10px;">🚚</div>
                        <p>No supplier data</p>
                    </div>
                <?php endif; ?>
                
                <!-- Inventory Health -->
                <h3 style="margin-top: 30px;">📈 Inventory Health</h3>
                <div style="background: #f8fafc; padding: 20px; border-radius: 10px;">
                    <div style="margin-bottom: 15px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span style="font-size: 0.9rem; color: #6b7280;">Stock Coverage</span>
                            <span style="font-weight: bold; color: #667eea;">
                                <?php 
                                $coverage = $total_items > 0 ? (($total_items - $low_stock - $out_of_stock) / $total_items) * 100 : 100;
                                echo round($coverage, 1); ?>%
                            </span>
                        </div>
                        <div style="height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden;">
                            <div style="height: 100%; background: linear-gradient(90deg, #667eea, #764ba2); width: <?php echo $coverage; ?>%; border-radius: 4px;"></div>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span style="font-size: 0.9rem; color: #6b7280;">Turnover Rate</span>
                            <span style="font-weight: bold; color: #10b981;">Good</span>
                        </div>
                        <div style="height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden;">
                            <div style="height: 100%; background: linear-gradient(90deg, #10b981, #059669); width: 75%; border-radius: 4px;"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span style="font-size: 0.9rem; color: #6b7280;">Reorder Efficiency</span>
                            <span style="font-weight: bold; color: #f59e0b;">Needs Attention</span>
                        </div>
                        <div style="height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden;">
                            <div style="height: 100%; background: linear-gradient(90deg, #f59e0b, #d97706); width: 40%; border-radius: 4px;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <h3 style="margin-top: 40px;">⚡ Quick Actions</h3>
        <div class="quick-actions">
            <a href="add_material.php" class="action-btn">
                <div class="action-icon">➕</div>
                <div style="font-weight: 600; color: #333;">Add New Item</div>
                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 5px;">
                    Register new material
                </div>
            </a>
            
            <a href="purchase_order.php" class="action-btn">
                <div class="action-icon">🛒</div>
                <div style="font-weight: 600; color: #333;">Create PO</div>
                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 5px;">
                    Purchase order
                </div>
            </a>
            
            <a href="stock_out.php" class="action-btn">
                <div class="action-icon">📤</div>
                <div style="font-weight: 600; color: #333;">Issue Stock</div>
                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 5px;">
                    Issue to project
                </div>
            </a>
            
            <a href="stock_in.php" class="action-btn">
                <div class="action-icon">📥</div>
                <div style="font-weight: 600; color: #333;">Receive Stock</div>
                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 5px;">
                    Stock in entry
                </div>
            </a>
            
            <a href="suppliers.php" class="action-btn">
                <div class="action-icon">🚚</div>
                <div style="font-weight: 600; color: #333;">Suppliers</div>
                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 5px;">
                    Manage suppliers
                </div>
            </a>
            
            <a href="reports.php" class="action-btn">
                <div class="action-icon">📊</div>
                <div style="font-weight: 600; color: #333;">Reports</div>
                <div style="font-size: 0.9rem; color: #6b7280; margin-top: 5px;">
                    Inventory reports
                </div>
            </a>
        </div>
    </div>
</div>

<script>
function createPO(materialId) {
    Swal.fire({
        title: 'Create Purchase Order?',
        text: 'Create a purchase order for this low stock item.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#f59e0b',
        confirmButtonText: 'Create PO'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `purchase_order.php?material_id=${materialId}`;
        }
    });
}

// Animate progress bars
document.addEventListener('DOMContentLoaded', function() {
    // Stock coverage bar
    const coverageBar = document.querySelector('div[style*="linear-gradient(90deg, #667eea"]');
    if (coverageBar) {
        const width = coverageBar.style.width;
        coverageBar.style.width = '0%';
        setTimeout(() => {
            coverageBar.style.transition = 'width 2s ease';
            coverageBar.style.width = width;
        }, 300);
    }
    
    // Add animations to movement cards
    const movementCards = document.querySelectorAll('.stock-movement');
    movementCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.style.animation = 'fadeInUp 0.5s ease';
    });
});

// Auto-refresh every 3 minutes
setTimeout(function() {
    location.reload();
}, 180000);

// CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
document.head.appendChild(style);
</script>
</body>
</html>
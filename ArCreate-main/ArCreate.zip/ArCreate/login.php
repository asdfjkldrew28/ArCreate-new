<?php
session_start();
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if it's login or registration
    if (isset($_POST['action']) && $_POST['action'] === 'register') {
        // Client registration
        $username = $conn->real_escape_string($_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $full_name = $conn->real_escape_string($_POST['full_name']);
        $email = $conn->real_escape_string($_POST['email']);
        $phone = $conn->real_escape_string($_POST['phone']);
        
        // Check if username exists
        $check_stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
        $check_stmt->bind_param("s", $username);
        $check_stmt->execute();
        
        if ($check_stmt->get_result()->num_rows > 0) {
            $err = "Username already exists!";
        } else {
            // Create user with client role
            $stmt = $conn->prepare("INSERT INTO users (username, password, role, full_name, email, phone) VALUES (?, ?, 'client', ?, ?, ?)");
            $stmt->bind_param("sssss", $username, $password, $full_name, $email, $phone);
            
            if ($stmt->execute()) {
                $success = "Account created successfully! Please login.";
            } else {
                $err = "Registration failed: " . $conn->error;
            }
        }
    } else {
        // Login
        $u = $conn->real_escape_string($_POST['username']);
        $p = $_POST['password'];
        
        $stmt = $conn->prepare("SELECT user_id, username, password, role, full_name FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param("s",$u);
        $stmt->execute();
        $res = $stmt->get_result();
        
        if ($res && $res->num_rows === 1) {
            $row = $res->fetch_assoc();
            
            if (password_verify($p, $row['password'])) {
                $_SESSION['user_id'] = $row['user_id'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['role'] = $row['role'];
                $_SESSION['full_name'] = $row['full_name'];
                
                // Role-based redirection
                switch ($row['role']) {
                    case 'admin':
                        header('Location: dashboard_admin.php');
                        break;
                    case 'foreman':
                        header('Location: dashboard_foreman.php');
                        break;
                    case 'client':
                        header('Location: client_dashboard.php');
                        break;
                    default:
                        header('Location: index.php');
                }
                exit;
            }
        }
        $err = "Invalid credentials";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login - ArCreate Architecture System</title>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.login-container {
    background: rgba(255, 255, 255, 0.95);
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 450px;
}

.tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 30px;
    border-bottom: 2px solid #e5e7eb;
    padding-bottom: 10px;
}

.tab {
    padding: 10px 20px;
    border: none;
    background: none;
    font-size: 1rem;
    font-weight: 600;
    color: #6b7280;
    cursor: pointer;
    border-radius: 8px;
    transition: all 0.3s;
}

.tab.active {
    background: #667eea;
    color: white;
}

.tab-content {
    display: none;
}

.tab-content.active {
    display: block;
}

h2 {
    color: #764ba2;
    text-align: center;
    margin-bottom: 10px;
    font-size: 1.8rem;
    font-weight: 600;
}

h2 i {
    margin-right: 10px;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    margin-bottom: 8px;
    color: #333;
    font-weight: 600;
}

input[type="text"],
input[type="password"],
input[type="email"],
input[type="tel"] {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #667eea;
    border-radius: 10px;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.btn-login {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-top: 10px;
}

.btn-login:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
}

.error {
    background: #ffe6ef;
    color: #a7002a;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
    font-weight: 600;
}

.success {
    background: #d1fae5;
    color: #065f46;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
    font-weight: 600;
}

.system-logo {
    text-align: center;
    margin-bottom: 20px;
    padding-bottom: 20px;
    border-bottom: 1px solid #e5e7eb;
}

.system-logo img {
    max-height: 80px;
    margin-bottom: 10px;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.system-logo h1 {
    color: #764ba2;
    font-size: 2rem;
    margin-bottom: 5px;
}

.system-logo p {
    color: #666;
    font-size: 0.9rem;
}

.forgot-password {
    text-align: center;
    margin-top: 15px;
    color: #666;
}

.forgot-password a {
    color: #667eea;
    text-decoration: none;
    font-weight: 600;
}

.powered-by {
    text-align: center;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #e5e7eb;
    color: #888;
    font-size: 0.85rem;
}

.login-footer {
    text-align: center;
    margin-top: 20px;
    font-size: 0.85rem;
    color: #666;
}

.login-footer a {
    color: #667eea;
    text-decoration: none;
    font-weight: 600;
}
</style>
</head>
<body>
<div class="login-container">
    <div class="system-logo">
        <?php
        // Check if logo file exists
        $logo_path = 'JMJCreations.jpg';
        if (file_exists($logo_path)):
        ?>
            <img src="<?php echo $logo_path; ?>" alt="ArCreate Logo" style="max-height: 80px;">
        <?php else: ?>
            <!-- Fallback to icon if logo not found -->
            <div style="font-size: 3rem; color: #667eea; margin-bottom: 10px;">
                🏗️
            </div>
        <?php endif; ?>
        <h1>ArCreate</h1>
        <p>Architecture & Construction Management System</p>
    </div>
    
    <div class="tabs">
        <button class="tab active" onclick="switchTab('login')">Login</button>
        <button class="tab" onclick="switchTab('register')">Client Registration</button>
    </div>
    
    <?php if(isset($err)): ?>
        <div class="error">❌ <?php echo $err; ?></div>
    <?php endif; ?>
    
    <?php if(isset($success)): ?>
        <div class="success">✅ <?php echo $success; ?></div>
    <?php endif; ?>

    <!-- Login Form -->
    <div id="login-tab" class="tab-content active">
        <h2><i class="fas fa-sign-in-alt"></i> Welcome Back</h2>
        <form method="post" id="loginForm">
            <div class="form-group">
                <label for="username"><i class="fas fa-user"></i> Username</label>
                <input type="text" id="username" name="username" required autocomplete="username" placeholder="Enter your username">
            </div>
            
            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Password</label>
                <input type="password" id="password" name="password" required autocomplete="current-password" placeholder="Enter your password">
            </div>
            
            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt"></i> Sign In to ArCreate
            </button>
        </form>
        
        <div class="forgot-password">
            <a href="#" id="forgotPasswordBtn">
                <i class="fas fa-question-circle"></i> Forgot Password?
            </a>
        </div>
    </div>

    <!-- Registration Form -->
    <div id="register-tab" class="tab-content">
        <h2><i class="fas fa-user-plus"></i> New Client Account</h2>
        <form method="post" id="registerForm">
            <input type="hidden" name="action" value="register">
            
            <div class="form-group">
                <label for="reg_username"><i class="fas fa-user"></i> Username *</label>
                <input type="text" id="reg_username" name="username" required placeholder="Choose a username">
            </div>
            
            <div class="form-group">
                <label for="reg_password"><i class="fas fa-lock"></i> Password *</label>
                <input type="password" id="reg_password" name="password" required placeholder="At least 6 characters">
            </div>
            
            <div class="form-group">
                <label for="full_name"><i class="fas fa-id-card"></i> Full Name *</label>
                <input type="text" id="full_name" name="full_name" required placeholder="Your full name">
            </div>
            
            <div class="form-group">
                <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                <input type="email" id="email" name="email" placeholder="you@example.com">
            </div>
            
            <div class="form-group">
                <label for="phone"><i class="fas fa-phone"></i> Phone Number</label>
                <input type="tel" id="phone" name="phone" placeholder="+63 912 345 6789">
            </div>
            
            <button type="submit" class="btn-login">
                <i class="fas fa-user-plus"></i> Create Client Account
            </button>
        </form>
        
        <div class="login-footer">
            Already have an account? <a href="#" onclick="switchTab('login')">Login here</a>
        </div>
    </div>
    
    <div class="powered-by">
        <i class="fas fa-cogs"></i> Powered by ArCreate Construction Management System
    </div>
</div>

<script>
// Auto-focus on username field
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('username').focus();
});

function switchTab(tabName) {
    // Update tabs
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelector(`.tab[onclick*="${tabName}"]`).classList.add('active');
    
    // Update content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`${tabName}-tab`).classList.add('active');
    
    // Focus on first input
    setTimeout(() => {
        const firstInput = document.querySelector(`#${tabName}-tab input`);
        if (firstInput) firstInput.focus();
    }, 100);
}

// Form validation
document.getElementById('registerForm').addEventListener('submit', function(e) {
    const password = document.getElementById('reg_password').value;
    const username = document.getElementById('reg_username').value;
    
    if (password.length < 6) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'Weak Password',
            text: 'Password must be at least 6 characters long',
            confirmButtonColor: '#f59e0b'
        });
        return false;
    }
    
    if (username.length < 3) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'Invalid Username',
            text: 'Username must be at least 3 characters long',
            confirmButtonColor: '#f59e0b'
        });
        return false;
    }
    
    return true;
});

// Add visual feedback for input fields
document.querySelectorAll('input').forEach(input => {
    input.addEventListener('focus', function() {
        this.style.borderColor = '#764ba2';
        this.style.boxShadow = '0 0 0 3px rgba(118, 75, 162, 0.1)';
    });
    
    input.addEventListener('blur', function() {
        this.style.borderColor = '#667eea';
        this.style.boxShadow = 'none';
    });
});

// Forgot Password functionality
document.getElementById('forgotPasswordBtn').addEventListener('click', function(e) {
    e.preventDefault();
    
    Swal.fire({
        title: 'Forgot Password?',
        html: `
            <div style="text-align: center;">
                <div style="font-size: 3rem; margin-bottom: 15px; color: #667eea;">
                    <i class="fas fa-key"></i>
                </div>
                <p style="font-size: 1.1rem; margin-bottom: 10px;">
                    <strong>Password Reset Request</strong>
                </p>
                <p style="color: #666; margin-bottom: 20px;">
                    Please enter your username and we will notify the system administrator.
                    The admin will reset your password and contact you.
                </p>
                <input type="text" id="forgotUsername" class="swal2-input" placeholder="Enter your username" style="width: 80%;">
            </div>
        `,
        showCancelButton: true,
        confirmButtonColor: '#667eea',
        cancelButtonColor: '#6b7280',
        confirmButtonText: 'Submit Request',
        cancelButtonText: 'Cancel',
        reverseButtons: true,
        preConfirm: () => {
            const username = document.getElementById('forgotUsername').value;
            if (!username) {
                Swal.showValidationMessage('Please enter your username');
                return false;
            }
            return { username: username };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Send request to server
            const formData = new FormData();
            formData.append('action', 'forgot_password');
            formData.append('username', result.value.username);
            
            fetch('forgot_password_request.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Request Submitted!',
                        html: `
                            <div style="text-align: center;">
                                <p>${data.message}</p>
                                <div style="background: #f0f9ff; padding: 15px; border-radius: 10px; margin-top: 15px;">
                                    <p style="color: #0369a1; font-size: 0.9rem;">
                                        <i class="fas fa-info-circle"></i>
                                        The administrator has been notified and will contact you shortly.
                                    </p>
                                </div>
                            </div>
                        `,
                        confirmButtonColor: '#667eea'
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message,
                        confirmButtonColor: '#ef4444'
                    });
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Failed to submit request. Please try again.',
                    confirmButtonColor: '#ef4444'
                });
            });
        }
    });
});

// Add animation to logo
const logo = document.querySelector('.system-logo img');
if (logo) {
    logo.style.transform = 'scale(0.9)';
    setTimeout(() => {
        logo.style.transition = 'transform 0.5s ease';
        logo.style.transform = 'scale(1)';
    }, 100);
}
</script>
</body>
</html>
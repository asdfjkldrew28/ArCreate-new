<?php
// dashboard_admin.php - Admin Dashboard
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

include 'db_connect.php';
include 'config.php';

// System Statistics
$total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$total_projects = $conn->query("SELECT COUNT(*) as count FROM projects")->fetch_assoc()['count'];
$total_clients = $conn->query("SELECT COUNT(*) as count FROM clients")->fetch_assoc()['count'];
$total_suppliers = $conn->query("SELECT COUNT(*) as count FROM suppliers")->fetch_assoc()['count'];

// Financial Stats
$total_revenue = $conn->query("SELECT SUM(total_contract_amount) as total FROM projects")->fetch_assoc()['total'];
$pending_payments = $conn->query("SELECT SUM(balance) as total FROM projects")->fetch_assoc()['total'];
$total_inventory_value = $conn->query("SELECT SUM(quantity * unit_price) as total FROM materials")->fetch_assoc()['total'];

// Recent Activity
$recent_users = $conn->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
$recent_projects = $conn->query("
    SELECT p.*, c.client_name 
    FROM projects p 
    LEFT JOIN clients c ON p.client_id = c.client_id 
    ORDER BY p.created_at DESC 
    LIMIT 5
");

// System Health
$low_stock_count = $conn->query("SELECT COUNT(*) as count FROM materials WHERE quantity <= min_stock_level")->fetch_assoc()['count'];
$pending_inquiries = $conn->query("SELECT COUNT(*) as count FROM chatbot_inquiries WHERE status = 'new'")->fetch_assoc()['count'];
$active_projects = $conn->query("SELECT COUNT(*) as count FROM projects WHERE status NOT IN ('completed', 'cancelled')")->fetch_assoc()['count'];

// Role distribution
$role_distribution = $conn->query("
    SELECT role, COUNT(*) as count 
    FROM users 
    WHERE status = 'active' 
    GROUP BY role
");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard - ArCreate</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            min-height: 100vh;
        }
        
        .dashboard-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            color: white;
            padding: 30px 20px;
            position: sticky;
            top: 0;
            height: 100vh;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .logo img {
            max-height: 60px;
            margin-bottom: 10px;
        }
        
        .logo h2 {
            color: white;
            font-size: 1.5rem;
        }
        
        .user-info {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 2rem;
            color: white;
            font-weight: bold;
        }
        
        .user-name {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .user-role {
            color: #cbd5e1;
            font-size: 0.9rem;
            background: rgba(102, 126, 234, 0.2);
            padding: 4px 12px;
            border-radius: 15px;
            display: inline-block;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-item {
            margin-bottom: 10px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            color: #cbd5e1;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .nav-link:hover, .nav-link.active {
            background: rgba(102, 126, 234, 0.2);
            color: white;
        }
        
        .nav-link i {
            width: 20px;
            text-align: center;
        }
        
        /* Main Content Styles */
        .main-content {
            padding: 30px;
            overflow-y: auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .header h1 {
            color: #1e293b;
            font-size: 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            border: 1px solid #e5e7eb;
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-bottom: 15px;
        }
        
        .stat-icon.users { background: linear-gradient(135deg, #667eea, #764ba2); }
        .stat-icon.projects { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .stat-icon.clients { background: linear-gradient(135deg, #10b981, #059669); }
        .stat-icon.suppliers { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
        .stat-icon.revenue { background: linear-gradient(135deg, #ef4444, #dc2626); }
        .stat-icon.inventory { background: linear-gradient(135deg, #06b6d4, #0891b2); }
        
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #1e293b;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #64748b;
            font-size: 0.9rem;
        }
        
        .dashboard-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            border: 1px solid #e5e7eb;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .section-header h3 {
            color: #1e293b;
            font-size: 1.3rem;
        }
        
        .table-container {
            overflow-x: auto;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th {
            background: #f8fafc;
            padding: 12px 15px;
            text-align: left;
            color: #64748b;
            font-weight: 600;
            font-size: 0.9rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .data-table td {
            padding: 15px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .data-table tr:hover {
            background: #f8fafc;
        }
        
        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-active { background: #dcfce7; color: #166534; }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-completed { background: #dbeafe; color: #1e40af; }
        
        .chart-container {
            height: 300px;
            margin-top: 20px;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        
        .action-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            border: 2px solid #e5e7eb;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            color: inherit;
        }
        
        .action-card:hover {
            border-color: #667eea;
            transform: translateY(-3px);
        }
        
        .action-icon {
            font-size: 2rem;
            margin-bottom: 10px;
            color: #667eea;
        }
        
        .notification-badge {
            background: #ef4444;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            position: absolute;
            top: -5px;
            right: -5px;
        }
        
        .nav-link {
            position: relative;
        }
        
        .logout-btn {
            margin-top: auto;
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            border: none;
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .logout-btn:hover {
            background: rgba(239, 68, 68, 0.2);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <?php if (file_exists(SITE_LOGO)): ?>
                    <img src="<?php echo SITE_LOGO; ?>" alt="ArCreate Logo">
                <?php else: ?>
                    <div style="font-size: 2.5rem; margin-bottom: 10px;">🏗️</div>
                <?php endif; ?>
                <h2>ArCreate</h2>
            </div>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?>
                </div>
                <div class="user-name"><?php echo htmlspecialchars($_SESSION['full_name']); ?></div>
                <div class="user-role">System Administrator</div>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="dashboard_admin.php" class="nav-link active">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="manage_users.php" class="nav-link">
                        <i class="fas fa-users-cog"></i>
                        User Management
                    </a>
                </li>
                <li class="nav-item">
                    <a href="projects.php" class="nav-link">
                        <i class="fas fa-project-diagram"></i>
                        All Projects
                    </a>
                </li>
                <li class="nav-item">
                    <a href="clients.php" class="nav-link">
                        <i class="fas fa-user-tie"></i>
                        Clients
                    </a>
                </li>
                <li class="nav-item">
                    <a href="suppliers.php" class="nav-link">
                        <i class="fas fa-truck"></i>
                        Suppliers
                    </a>
                </li>
                <li class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="index.php" class="nav-link">
                        <i class="fas fa-boxes"></i>
                        Inventory
                    </a>
                </li>
                <li class="nav-item">
                    <a href="system_settings.php" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </li>
            </ul>
            
            <button class="logout-btn" onclick="logout()">
                <i class="fas fa-sign-out-alt"></i> Logout
            </button>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div>
                    <h1>Admin Dashboard</h1>
                    <p style="color: #64748b;">System overview and management</p>
                </div>
                <div style="color: #64748b;">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('F j, Y'); ?>
                </div>
            </div>
            
            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon users">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-value"><?php echo $total_users; ?></div>
                    <div class="stat-label">Total Users</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon projects">
                        <i class="fas fa-project-diagram"></i>
                    </div>
                    <div class="stat-value"><?php echo $total_projects; ?></div>
                    <div class="stat-label">Total Projects</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon clients">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="stat-value"><?php echo $total_clients; ?></div>
                    <div class="stat-label">Clients</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon suppliers">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="stat-value"><?php echo $total_suppliers; ?></div>
                    <div class="stat-label">Suppliers</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon revenue">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="stat-value">₱<?php echo number_format($total_revenue, 2); ?></div>
                    <div class="stat-label">Total Revenue</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon inventory">
                        <i class="fas fa-boxes"></i>
                    </div>
                    <div class="stat-value">₱<?php echo number_format($total_inventory_value, 2); ?></div>
                    <div class="stat-label">Inventory Value</div>
                </div>
            </div>
            
            <!-- Two Column Layout -->
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px;">
                <!-- Left Column -->
                <div>
                    <!-- Recent Projects -->
                    <div class="dashboard-section">
                        <div class="section-header">
                            <h3><i class="fas fa-project-diagram"></i> Recent Projects</h3>
                            <a href="projects.php" style="color: #667eea; text-decoration: none;">View All →</a>
                        </div>
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Project Name</th>
                                        <th>Client</th>
                                        <th>Status</th>
                                        <th>Budget</th>
                                        <th>Progress</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($recent_projects && $recent_projects->num_rows > 0): ?>
                                        <?php while($project = $recent_projects->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <div style="font-weight: 600;"><?php echo htmlspecialchars($project['project_name']); ?></div>
                                                <div style="font-size: 0.8rem; color: #64748b;">
                                                    <?php echo $project['project_type']; ?>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($project['client_name']); ?></td>
                                            <td>
                                                <span class="status-badge status-<?php echo str_replace(' ', '-', strtolower($project['status'])); ?>">
                                                    <?php echo ucfirst($project['status']); ?>
                                                </span>
                                            </td>
                                            <td>₱<?php echo number_format($project['total_contract_amount'], 2); ?></td>
                                            <td>
                                                <div style="display: flex; align-items: center; gap: 10px;">
                                                    <div style="flex: 1; height: 6px; background: #e5e7eb; border-radius: 3px;">
                                                        <div style="width: <?php echo $project['completion_percentage'] ?? 0; ?>%; height: 100%; background: #10b981; border-radius: 3px;"></div>
                                                    </div>
                                                    <span style="font-weight: 600;"><?php echo $project['completion_percentage'] ?? 0; ?>%</span>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" style="text-align: center; padding: 40px;">
                                                <div style="font-size: 3rem; margin-bottom: 20px;">📋</div>
                                                <p>No projects found</p>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="dashboard-section">
                        <h3 style="margin-bottom: 20px;"><i class="fas fa-bolt"></i> Quick Actions</h3>
                        <div class="quick-actions">
                            <a href="manage_users.php" class="action-card">
                                <div class="action-icon">
                                    <i class="fas fa-user-plus"></i>
                                </div>
                                <div style="font-weight: 600;">Add User</div>
                                <div style="font-size: 0.9rem; color: #64748b; margin-top: 5px;">
                                    Create new user account
                                </div>
                            </a>
                            
                            <a href="create_project.php" class="action-card">
                                <div class="action-icon">
                                    <i class="fas fa-plus-circle"></i>
                                </div>
                                <div style="font-weight: 600;">New Project</div>
                                <div style="font-size: 0.9rem; color: #64748b; margin-top: 5px;">
                                    Start a new project
                                </div>
                            </a>
                            
                            <a href="system_settings.php" class="action-card">
                                <div class="action-icon">
                                    <i class="fas fa-cog"></i>
                                </div>
                                <div style="font-weight: 600;">System Settings</div>
                                <div style="font-size: 0.9rem; color: #64748b; margin-top: 5px;">
                                    Configure system
                                </div>
                            </a>
                            
                            <a href="reports.php" class="action-card">
                                <div class="action-icon">
                                    <i class="fas fa-chart-line"></i>
                                </div>
                                <div style="font-weight: 600;">Generate Report</div>
                                <div style="font-size: 0.9rem; color: #64748b; margin-top: 5px;">
                                    Create system report
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Right Column -->
                <div>
                    <!-- System Health -->
                    <div class="dashboard-section">
                        <h3 style="margin-bottom: 20px;"><i class="fas fa-heartbeat"></i> System Health</h3>
                        <div style="margin-bottom: 20px;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                <span>Active Projects</span>
                                <span style="font-weight: 600; color: #10b981;"><?php echo $active_projects; ?></span>
                            </div>
                            <div style="height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden;">
                                <div style="width: <?php echo min(100, ($active_projects / max(1, $total_projects)) * 100); ?>%; height: 100%; background: linear-gradient(90deg, #10b981, #059669); border-radius: 4px;"></div>
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 20px;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                <span>Low Stock Items</span>
                                <span style="font-weight: 600; color: <?php echo $low_stock_count > 0 ? '#f59e0b' : '#10b981'; ?>">
                                    <?php echo $low_stock_count; ?>
                                </span>
                            </div>
                            <div style="height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden;">
                                <div style="width: <?php echo min(100, ($low_stock_count / 50) * 100); ?>%; height: 100%; background: linear-gradient(90deg, #f59e0b, #d97706); border-radius: 4px;"></div>
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 20px;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                <span>Pending Inquiries</span>
                                <span style="font-weight: 600; color: <?php echo $pending_inquiries > 0 ? '#ef4444' : '#10b981'; ?>">
                                    <?php echo $pending_inquiries; ?>
                                </span>
                            </div>
                            <div style="height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden;">
                                <div style="width: <?php echo min(100, ($pending_inquiries / 20) * 100); ?>%; height: 100%; background: linear-gradient(90deg, #ef4444, #dc2626); border-radius: 4px;"></div>
                            </div>
                        </div>
                        
                        <div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                <span>Pending Payments</span>
                                <span style="font-weight: 600; color: #667eea;">
                                    ₱<?php echo number_format($pending_payments, 2); ?>
                                </span>
                            </div>
                            <div style="height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden;">
                                <div style="width: <?php echo min(100, ($pending_payments / max(1, $total_revenue)) * 100); ?>%; height: 100%; background: linear-gradient(90deg, #667eea, #764ba2); border-radius: 4px;"></div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Recent Users -->
                    <div class="dashboard-section">
                        <div class="section-header">
                            <h3><i class="fas fa-user-clock"></i> Recent Users</h3>
                            <a href="manage_users.php" style="color: #667eea; text-decoration: none;">View All →</a>
                        </div>
                        <div style="max-height: 300px; overflow-y: auto;">
                            <?php if ($recent_users && $recent_users->num_rows > 0): ?>
                                <?php while($user = $recent_users->fetch_assoc()): ?>
                                <div style="display: flex; align-items: center; gap: 12px; padding: 12px; border-bottom: 1px solid #e5e7eb;">
                                    <div style="width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                        <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                                    </div>
                                    <div style="flex: 1;">
                                        <div style="font-weight: 600; color: #1e293b;"><?php echo htmlspecialchars($user['full_name']); ?></div>
                                        <div style="font-size: 0.8rem; color: #64748b;">
                                            <?php echo $user['role']; ?> • <?php echo date('M d', strtotime($user['created_at'])); ?>
                                        </div>
                                    </div>
                                    <span class="status-badge <?php echo $user['status'] == 'active' ? 'status-active' : 'status-pending'; ?>">
                                        <?php echo ucfirst($user['status']); ?>
                                    </span>
                                </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <div style="text-align: center; padding: 20px; color: #64748b;">
                                    <div style="font-size: 2rem; margin-bottom: 10px;">👤</div>
                                    <p>No recent users</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- User Role Distribution Chart -->
                    <div class="dashboard-section">
                        <h3 style="margin-bottom: 20px;"><i class="fas fa-chart-pie"></i> User Roles</h3>
                        <div class="chart-container">
                            <canvas id="roleChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function logout() {
        Swal.fire({
            title: 'Logout?',
            text: 'Are you sure you want to logout?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#667eea',
            cancelButtonColor: '#6b7280',
            confirmButtonText: 'Yes, Logout'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'logout.php';
            }
        });
    }
    
    // Initialize role distribution chart
    document.addEventListener('DOMContentLoaded', function() {
        // Role distribution data
        const roleData = {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#667eea', // admin
                    '#f59e0b', // project_manager
                    '#10b981', // architect
                    '#8b5cf6', // site_engineer
                    '#ef4444', // accountant
                    '#06b6d4', // supplier
                    '#6b7280'  // client
                ]
            }]
        };
        
        <?php if ($role_distribution): ?>
            <?php while($role = $role_distribution->fetch_assoc()): ?>
                roleData.labels.push("<?php echo ucfirst(str_replace('_', ' ', $role['role'])); ?>");
                roleData.datasets[0].data.push(<?php echo $role['count']; ?>);
            <?php endwhile; ?>
        <?php endif; ?>
        
        const ctx = document.getElementById('roleChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: roleData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
        
        // Auto-refresh dashboard every 5 minutes
        setTimeout(() => {
            location.reload();
        }, 300000);
    });
    </script>
</body>
</html>
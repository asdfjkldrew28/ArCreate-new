<?php
// dashboard_foreman.php - Foreman Dashboard
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'foreman') {
    header('Location: login.php');
    exit;
}

include 'db_connect.php';
include 'config.php';

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];

// Foreman's Statistics
$active_projects = $conn->query("SELECT COUNT(*) as count FROM projects WHERE foreman_id = $user_id AND status IN ('construction', 'finishing')")->fetch_assoc()['count'];
$total_materials = $conn->query("SELECT COALESCE(SUM(quantity), 0) as total FROM materials")->fetch_assoc()['total'];
$low_stock_items = $conn->query("SELECT COUNT(*) as count FROM materials WHERE quantity <= min_stock_level")->fetch_assoc()['count'];

// Foreman's Projects
$projects = $conn->query("
    SELECT p.*, c.client_name, c.phone as client_phone
    FROM projects p 
    LEFT JOIN clients c ON p.client_id = c.client_id 
    WHERE p.foreman_id = $user_id 
    AND p.status IN ('construction', 'finishing')
    ORDER BY p.estimated_end_date ASC
    LIMIT 5
");

// Low Stock Alerts
$low_stock = $conn->query("
    SELECT m.*, s.supplier_name
    FROM materials m
    LEFT JOIN suppliers s ON m.supplier_id = s.supplier_id
    WHERE m.quantity <= m.min_stock_level
    ORDER BY m.quantity ASC
    LIMIT 5
");

// Recent stock movements
$recent_stock_out = $conn->query("
    SELECT so.*, m.material_name, p.project_name
    FROM stock_out so
    LEFT JOIN materials m ON so.material_id = m.material_id
    LEFT JOIN projects p ON so.project_id = p.project_id
    WHERE p.foreman_id = $user_id
    ORDER BY so.date_issued DESC
    LIMIT 5
");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Foreman Dashboard - ArCreate</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            min-height: 100vh;
        }
        
        .dashboard-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            background: linear-gradient(180deg, #f59e0b 0%, #d97706 100%);
            color: white;
            padding: 30px 20px;
            position: sticky;
            top: 0;
            height: 100vh;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }
        
        .logo img {
            max-height: 60px;
            margin-bottom: 10px;
            border-radius: 10px;
        }
        
        .logo h2 {
            color: white;
            font-size: 1.5rem;
        }
        
        .user-info {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #f59e0b, #d97706);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 2rem;
            color: white;
            font-weight: bold;
        }
        
        .user-name {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .user-role {
            color: white;
            font-size: 0.9rem;
            background: rgba(255,255,255,0.2);
            padding: 4px 12px;
            border-radius: 15px;
            display: inline-block;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-item {
            margin-bottom: 10px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            color: rgba(255,255,255,0.9);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        .nav-link i {
            width: 20px;
            text-align: center;
        }
        
        /* Main Content Styles */
        .main-content {
            padding: 30px;
            overflow-y: auto;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .header h1 {
            color: #1e293b;
            font-size: 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            border: 1px solid #e5e7eb;
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            margin-bottom: 15px;
        }
        
        .stat-icon.projects { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .stat-icon.materials { background: linear-gradient(135deg, #10b981, #059669); }
        .stat-icon.low { background: linear-gradient(135deg, #ef4444, #dc2626); }
        .stat-icon.stock { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
        
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #1e293b;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #64748b;
            font-size: 0.9rem;
        }
        
        .dashboard-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            border: 1px solid #e5e7eb;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .section-header h3 {
            color: #1e293b;
            font-size: 1.3rem;
        }
        
        .project-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            border: 2px solid #e5e7eb;
            transition: all 0.3s;
        }
        
        .project-card:hover {
            border-color: #f59e0b;
            transform: translateY(-3px);
        }
        
        .project-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .project-status {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-construction { background: #fef3c7; color: #92400e; }
        .status-finishing { background: #fce7f3; color: #9d174d; }
        
        .alert-card {
            background: #fef3c7;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
            border-left: 4px solid #f59e0b;
        }
        
        .stock-card {
            background: #f0f9ff;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
            border-left: 4px solid #3b82f6;
        }
        
        .progress-bar {
            height: 8px;
            background: #e5e7eb;
            border-radius: 4px;
            margin: 10px 0;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #f59e0b, #d97706);
            border-radius: 4px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
        }
        
        .btn-secondary {
            background: #f3f4f6;
            color: #4b5563;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .logout-btn {
            margin-top: auto;
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            border: none;
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .logout-btn:hover {
            background: rgba(239, 68, 68, 0.2);
        }
        
        .material-quantity {
            font-size: 1.2rem;
            font-weight: bold;
            color: #ef4444;
        }
        
        .client-info {
            font-size: 0.9rem;
            color: #64748b;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <?php if (defined('SITE_LOGO') && file_exists(SITE_LOGO)): ?>
                    <img src="<?php echo SITE_LOGO; ?>" alt="ArCreate Logo">
                <?php else: ?>
                    <div style="font-size: 2.5rem; margin-bottom: 10px;">👷</div>
                <?php endif; ?>
                <h2>ArCreate</h2>
            </div>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($full_name, 0, 1)); ?>
                </div>
                <div class="user-name"><?php echo htmlspecialchars($full_name); ?></div>
                <div class="user-role">Site Foreman</div>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="dashboard_foreman.php" class="nav-link active">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="index.php" class="nav-link">
                        <i class="fas fa-warehouse"></i>
                        Inventory
                    </a>
                </li>
                <li class="nav-item">
                    <a href="my_projects.php" class="nav-link">
                        <i class="fas fa-hard-hat"></i>
                        My Projects
                    </a>
                </li>
                <li class="nav-item">
                    <a href="daily_report.php" class="nav-link">
                        <i class="fas fa-clipboard-list"></i>
                        Daily Reports
                    </a>
                </li>
                <li class="nav-item">
                    <a href="material_requests.php" class="nav-link">
                        <i class="fas fa-truck-loading"></i>
                        Material Requests
                    </a>
                </li>
                <li class="nav-item">
                    <a href="safety_checklist.php" class="nav-link">
                        <i class="fas fa-shield-alt"></i>
                        Safety
                    </a>
                </li>
                <li class="nav-item">
                    <a href="profile.php" class="nav-link">
                        <i class="fas fa-user-cog"></i>
                        Profile
                    </a>
                </li>
            </ul>
            
            <button class="logout-btn" onclick="logout()">
                <i class="fas fa-sign-out-alt"></i> Logout
            </button>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div>
                    <h1>Foreman Dashboard</h1>
                    <p style="color: #64748b;">Site management and material tracking</p>
                </div>
                <div style="color: #64748b;">
                    <i class="fas fa-calendar-alt"></i> <?php echo date('F j, Y'); ?>
                </div>
            </div>
            
            <!-- Welcome Message -->
            <div class="dashboard-section" style="background: linear-gradient(135deg, #f59e0b, #d97706); color: white;">
                <div style="display: flex; align-items: center; gap: 20px;">
                    <div style="font-size: 3rem;">
                        <i class="fas fa-hard-hat"></i>
                    </div>
                    <div>
                        <h2 style="color: white; margin-bottom: 5px;">Welcome, <?php echo htmlspecialchars($full_name); ?>!</h2>
                        <p style="opacity: 0.9;">Manage your construction site efficiently</p>
                    </div>
                </div>
            </div>
            
            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon projects">
                        <i class="fas fa-hard-hat"></i>
                    </div>
                    <div class="stat-value"><?php echo $active_projects; ?></div>
                    <div class="stat-label">Active Projects</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon materials">
                        <i class="fas fa-boxes"></i>
                    </div>
                    <div class="stat-value"><?php echo $total_materials; ?></div>
                    <div class="stat-label">Total Materials</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon low">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-value"><?php echo $low_stock_items; ?></div>
                    <div class="stat-label">Low Stock Items</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon stock">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="stat-value"><?php echo $recent_stock_out->num_rows ?? 0; ?></div>
                    <div class="stat-label">Recent Issues</div>
                </div>
            </div>
            
            <!-- Two Column Layout -->
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px;">
                <!-- Left Column -->
                <div>
                    <!-- My Projects -->
                    <div class="dashboard-section">
                        <div class="section-header">
                            <h3><i class="fas fa-hard-hat"></i> My Active Projects</h3>
                            <a href="my_projects.php" style="color: #f59e0b; text-decoration: none;">View All →</a>
                        </div>
                        <?php if ($projects && $projects->num_rows > 0): ?>
                            <?php while($project = $projects->fetch_assoc()): ?>
                            <div class="project-card">
                                <div class="project-header">
                                    <div>
                                        <h4 style="color: #1e293b; margin-bottom: 5px;">
                                            <?php echo htmlspecialchars($project['project_name']); ?>
                                        </h4>
                                        <div class="client-info">
                                            Client: <?php echo htmlspecialchars($project['client_name'] ?? 'Not assigned'); ?>
                                        </div>
                                    </div>
                                    <span class="project-status status-<?php echo $project['status']; ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $project['status'])); ?>
                                    </span>
                                </div>
                                
                                <div style="margin-bottom: 15px;">
                                    <div style="font-size: 0.9rem; color: #64748b; margin-bottom: 10px;">
                                        <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($project['address'] ?? 'Address not specified'); ?>
                                    </div>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                                        <div>
                                            <div style="font-size: 0.9rem; color: #64748b;">
                                                <strong>Start:</strong> <?php echo $project['start_date'] ? date('M d, Y', strtotime($project['start_date'])) : 'Not set'; ?>
                                            </div>
                                            <div style="font-size: 0.9rem; color: #64748b;">
                                                <strong>Est. End:</strong> <?php echo $project['estimated_end_date'] ? date('M d, Y', strtotime($project['estimated_end_date'])) : 'Not set'; ?>
                                            </div>
                                        </div>
                                        <div>
                                            <div style="font-size: 0.9rem; color: #64748b; font-weight: 600;">
                                                <i class="fas fa-phone"></i> <?php echo $project['client_phone'] ?? 'No contact'; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div style="display: flex; gap: 10px; margin-top: 15px;">
                                    <a href="view_project.php?id=<?php echo $project['project_id']; ?>" class="btn btn-primary">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    <a href="daily_report.php?project_id=<?php echo $project['project_id']; ?>" class="btn btn-secondary">
                                        <i class="fas fa-clipboard-list"></i> Report
                                    </a>
                                    <a href="material_requests.php?project_id=<?php echo $project['project_id']; ?>" class="btn btn-success">
                                        <i class="fas fa-truck-loading"></i> Request Materials
                                    </a>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div style="text-align: center; padding: 40px; color: #64748b;">
                                <div style="font-size: 3rem; margin-bottom: 20px;">🏗️</div>
                                <h3>No Active Projects</h3>
                                <p>You are not assigned to any active projects.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Right Column -->
                <div>
                    <!-- Low Stock Alerts -->
                    <div class="dashboard-section">
                        <h3 style="margin-bottom: 20px;"><i class="fas fa-exclamation-triangle"></i> Low Stock Alerts</h3>
                        <?php if ($low_stock && $low_stock->num_rows > 0): ?>
                            <div style="max-height: 300px; overflow-y: auto;">
                                <?php while($item = $low_stock->fetch_assoc()): ?>
                                <div class="alert-card">
                                    <div style="font-weight: 600; color: #92400e; margin-bottom: 5px;">
                                        <?php echo htmlspecialchars($item['material_name']); ?>
                                    </div>
                                    <div style="font-size: 0.9rem; color: #64748b; margin-bottom: 5px;">
                                        <?php echo htmlspecialchars($item['location']); ?>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <div>
                                            <div class="material-quantity">
                                                <?php echo $item['quantity']; ?> <?php echo $item['unit']; ?>
                                            </div>
                                            <div style="font-size: 0.8rem; color: #9ca3af;">
                                                Min: <?php echo $item['min_stock_level']; ?>
                                            </div>
                                        </div>
                                        <a href="material_requests.php?material_id=<?php echo $item['material_id']; ?>" class="btn" style="background: #f59e0b; color: white; padding: 5px 10px; font-size: 0.8rem;">
                                            <i class="fas fa-shopping-cart"></i> Order
                                        </a>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div style="text-align: center; padding: 20px; color: #64748b;">
                                <div style="font-size: 2rem; margin-bottom: 10px;">✅</div>
                                <p>All stock levels are good</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Recent Stock Issues -->
                    <div class="dashboard-section">
                        <h3 style="margin-bottom: 20px;"><i class="fas fa-truck"></i> Recent Stock Issues</h3>
                        <?php if ($recent_stock_out && $recent_stock_out->num_rows > 0): ?>
                            <div style="max-height: 250px; overflow-y: auto;">
                                <?php while($stock = $recent_stock_out->fetch_assoc()): ?>
                                <div class="stock-card">
                                    <div style="font-weight: 600; color: #1e293b; margin-bottom: 5px;">
                                        <?php echo htmlspecialchars($stock['material_name']); ?>
                                    </div>
                                    <div style="font-size: 0.9rem; color: #64748b; margin-bottom: 5px;">
                                        Project: <?php echo htmlspecialchars($stock['project_name'] ?? 'General Use'); ?>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <div>
                                            <div style="color: #ef4444; font-weight: 600;">
                                                -<?php echo $stock['quantity']; ?>
                                            </div>
                                            <div style="font-size: 0.8rem; color: #9ca3af;">
                                                <?php echo date('M d', strtotime($stock['date_issued'])); ?>
                                            </div>
                                        </div>
                                        <?php if ($stock['purpose']): ?>
                                        <div style="font-size: 0.8rem; color: #6b7280; font-style: italic;">
                                            <?php echo substr($stock['purpose'], 0, 30); ?>...
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div style="text-align: center; padding: 20px; color: #64748b;">
                                <div style="font-size: 2rem; margin-bottom: 10px;">📤</div>
                                <p>No recent stock issues</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="dashboard-section">
                        <h3 style="margin-bottom: 20px;"><i class="fas fa-bolt"></i> Quick Actions</h3>
                        <div style="display: grid; gap: 10px;">
                            <a href="daily_report.php" class="btn btn-primary">
                                <i class="fas fa-clipboard-list"></i> Daily Report
                            </a>
                            <a href="material_requests.php" class="btn btn-secondary">
                                <i class="fas fa-truck-loading"></i> Request Materials
                            </a>
                            <a href="index.php" class="btn btn-success">
                                <i class="fas fa-warehouse"></i> View Inventory
                            </a>
                            <a href="safety_checklist.php" class="btn" style="background: #ef4444; color: white;">
                                <i class="fas fa-shield-alt"></i> Safety Check
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function logout() {
        Swal.fire({
            title: 'Logout?',
            text: 'Are you sure you want to logout?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#f59e0b',
            cancelButtonColor: '#6b7280',
            confirmButtonText: 'Yes, Logout'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'logout.php';
            }
        });
    }
    
    // Auto-refresh dashboard every 5 minutes
    setTimeout(() => {
        location.reload();
    }, 300000);
    </script>
</body>
</html>
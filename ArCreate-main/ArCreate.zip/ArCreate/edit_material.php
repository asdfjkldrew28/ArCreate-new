<?php
// edit_material.php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'foreman'])) {
    header('Location: login.php');
    exit;
}

include 'db_connect.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$material = null;
$success = false;
$error = '';

// Fetch material details
if ($id) {
    $stmt = $conn->prepare("SELECT * FROM materials WHERE material_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $material = $result->fetch_assoc();
    
    if (!$material) {
        header('Location: index.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $material) {
    try {
        $old_data = $material;
        
        $material_name = $conn->real_escape_string($_POST['material_name']);
        $category = $conn->real_escape_string($_POST['category']);
        $description = $conn->real_escape_string($_POST['description']);
        $quantity = (int)$_POST['quantity'];
        $unit = $conn->real_escape_string($_POST['unit']);
        $unit_price = floatval($_POST['unit_price']);
        $location = $conn->real_escape_string($_POST['location']);
        $supplier_id = !empty($_POST['supplier_id']) ? (int)$_POST['supplier_id'] : NULL;
        $min_stock_level = (int)$_POST['min_stock_level'];
        $reorder_level = (int)$_POST['reorder_level'];
        $status = $conn->real_escape_string($_POST['status']);
        
        $stmt = $conn->prepare("UPDATE materials SET material_name = ?, category = ?, description = ?, quantity = ?, unit = ?, unit_price = ?, location = ?, supplier_id = ?, min_stock_level = ?, reorder_level = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE material_id = ?");
        $stmt->bind_param("sssisdsiiissi", $material_name, $category, $description, $quantity, $unit, $unit_price, $location, $supplier_id, $min_stock_level, $reorder_level, $status, $id);
        
        if ($stmt->execute()) {
            $success = true;
            
            // Track changes
            $changes = [];
            foreach ($old_data as $key => $value) {
                $new_value = $$key;
                if ($new_value != $value && !in_array($key, ['updated_at', 'created_at'])) {
                    $changes[$key] = ['old' => $value, 'new' => $new_value];
                }
            }
            
            if (!empty($changes)) {
                $log_query = "INSERT INTO change_logs (username, action, table_name, record_id, changes) VALUES (?, 'UPDATE', 'materials', ?, ?)";
                $log_stmt = $conn->prepare($log_query);
                $changes_json = json_encode($changes);
                $log_stmt->bind_param("sis", $_SESSION['username'], $id, $changes_json);
                $log_stmt->execute();
            }
        } else {
            $error = "Failed to update material: " . $conn->error;
        }
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Fetch suppliers
$suppliers = $conn->query("SELECT supplier_id, supplier_name FROM suppliers WHERE status='active' ORDER BY supplier_name");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Edit Material - ArCreate</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Same styles as add_material.php */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #1e40af;
            font-size: 2rem;
        }
        
        .header-icon {
            font-size: 2rem;
            color: #667eea;
        }
        
        .material-info {
            background: #f8fafc;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid #667eea;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .required::after {
            content: " *";
            color: #ef4444;
        }
        
        input, select, textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-secondary {
            background: #f3f4f6;
            color: #4b5563;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="header-icon">
                <i class="fas fa-edit"></i>
            </div>
            <div>
                <h1>Edit Material</h1>
                <p style="color: #6b7280;">Update material details and stock information</p>
            </div>
        </div>
        
        <?php if ($material): ?>
        <div class="material-info">
            <strong>Current Status:</strong>
            <span style="color: #667eea; font-weight: 600;">
                <?php echo $material['quantity']; ?> <?php echo $material['unit']; ?> in stock
            </span>
            |
            <strong>Category:</strong>
            <span style="color: #667eea;"><?php echo ucfirst($material['category']); ?></span>
            |
            <strong>Last Updated:</strong>
            <span style="color: #667eea;"><?php echo $material['updated_at'] ?? 'Never'; ?></span>
        </div>
        
        <?php if ($error): ?>
        <div id="errorAlert" style="display: none;"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
        <div id="successAlert" style="display: none;">Material updated successfully!</div>
        <?php endif; ?>
        
        <form method="post" id="editMaterialForm">
            <div class="form-group">
                <label for="material_name" class="required">Material Name</label>
                <input type="text" id="material_name" name="material_name" required 
                       value="<?php echo htmlspecialchars($material['material_name']); ?>">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="category" class="required">Category</label>
                    <select id="category" name="category" required>
                        <?php
                        $categories = [
                            'construction' => '🏗️ Construction',
                            'hardware' => '🔧 Hardware',
                            'electrical' => '⚡ Electrical',
                            'plumbing' => '🚰 Plumbing',
                            'finishing' => '🎨 Finishing',
                            'tools' => '🛠️ Tools',
                            'safety' => '🦺 Safety',
                            'office' => '📁 Office'
                        ];
                        foreach ($categories as $value => $label):
                        ?>
                        <option value="<?php echo $value; ?>" <?php echo $material['category'] == $value ? 'selected' : ''; ?>>
                            <?php echo $label; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="quantity" class="required">Current Quantity</label>
                    <input type="number" id="quantity" name="quantity" required min="0" 
                           value="<?php echo $material['quantity']; ?>">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="unit" class="required">Unit</label>
                    <select id="unit" name="unit" required>
                        <option value="pcs" <?php echo $material['unit'] == 'pcs' ? 'selected' : ''; ?>>Pieces (pcs)</option>
                        <option value="bags" <?php echo $material['unit'] == 'bags' ? 'selected' : ''; ?>>Bags</option>
                        <option value="kg" <?php echo $material['unit'] == 'kg' ? 'selected' : ''; ?>>Kilograms (kg)</option>
                        <option value="m" <?php echo $material['unit'] == 'm' ? 'selected' : ''; ?>>Meters (m)</option>
                        <option value="roll" <?php echo $material['unit'] == 'roll' ? 'selected' : ''; ?>>Rolls</option>
                        <option value="set" <?php echo $material['unit'] == 'set' ? 'selected' : ''; ?>>Sets</option>
                        <option value="box" <?php echo $material['unit'] == 'box' ? 'selected' : ''; ?>>Boxes</option>
                        <option value="liter" <?php echo $material['unit'] == 'liter' ? 'selected' : ''; ?>>Liters</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="unit_price" class="required">Unit Price (₱)</label>
                    <input type="number" id="unit_price" name="unit_price" required step="0.01" min="0" 
                           value="<?php echo $material['unit_price']; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="3"><?php echo htmlspecialchars($material['description']); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="location">Storage Location</label>
                <input type="text" id="location" name="location" 
                       value="<?php echo htmlspecialchars($material['location']); ?>">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="supplier_id">Supplier</label>
                    <select id="supplier_id" name="supplier_id">
                        <option value="">Select Supplier</option>
                        <?php while($supplier = $suppliers->fetch_assoc()): ?>
                        <option value="<?php echo $supplier['supplier_id']; ?>" 
                            <?php echo $material['supplier_id'] == $supplier['supplier_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($supplier['supplier_name']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="available" <?php echo $material['status'] == 'available' ? 'selected' : ''; ?>>Available</option>
                        <option value="unavailable" <?php echo $material['status'] == 'unavailable' ? 'selected' : ''; ?>>Unavailable</option>
                        <option value="discontinued" <?php echo $material['status'] == 'discontinued' ? 'selected' : ''; ?>>Discontinued</option>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="min_stock_level">Minimum Stock Level</label>
                    <input type="number" id="min_stock_level" name="min_stock_level" min="1" 
                           value="<?php echo $material['min_stock_level']; ?>">
                </div>
                
                <div class="form-group">
                    <label for="reorder_level">Reorder Level</label>
                    <input type="number" id="reorder_level" name="reorder_level" min="0" 
                           value="<?php echo $material['reorder_level']; ?>">
                </div>
            </div>
            
            <div class="btn-group">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Update Material
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancel
                </a>
                <a href="delete_material.php?id=<?php echo $id; ?>" class="btn btn-danger" id="deleteBtn">
                    <i class="fas fa-trash"></i> Delete
                </a>
            </div>
        </form>
        <?php else: ?>
        <div style="text-align: center; padding: 40px;">
            <div style="font-size: 3rem; margin-bottom: 20px;">❌</div>
            <h3>Material Not Found</h3>
            <p>The material you're trying to edit doesn't exist.</p>
            <a href="index.php" class="btn btn-primary" style="margin-top: 20px;">
                <i class="fas fa-arrow-left"></i> Back to Inventory
            </a>
        </div>
        <?php endif; ?>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const successAlert = document.getElementById('successAlert');
        const errorAlert = document.getElementById('errorAlert');
        const deleteBtn = document.getElementById('deleteBtn');
        
        if (successAlert) {
            Swal.fire({
                icon: 'success',
                title: 'Updated!',
                text: successAlert.textContent,
                confirmButtonColor: '#667eea',
                timer: 3000,
                timerProgressBar: true
            }).then(() => {
                window.location.href = 'index.php';
            });
        }
        
        if (errorAlert) {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: errorAlert.textContent,
                confirmButtonColor: '#ef4444'
            });
        }
        
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function(e) {
                e.preventDefault();
                
                Swal.fire({
                    title: 'Delete Material?',
                    html: `
                        <div style="text-align: center;">
                            <div style="font-size: 4rem; margin-bottom: 15px; color: #ef4444;">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                            <p style="font-size: 1.2rem; margin-bottom: 10px;">
                                Delete material:<br>
                                <strong>"<?php echo htmlspecialchars($material['material_name']); ?>"</strong>?
                            </p>
                            <p style="color: #ef4444; font-weight: 600; font-size: 1rem;">
                                This action cannot be undone!
                            </p>
                        </div>
                    `,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#ef4444',
                    cancelButtonColor: '#6b7280',
                    confirmButtonText: 'Yes, Delete',
                    cancelButtonText: 'Cancel',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = this.href;
                    }
                });
            });
        }
        
        // Form validation
        const form = document.getElementById('editMaterialForm');
        form.addEventListener('submit', function(e) {
            const unitPrice = document.getElementById('unit_price').value;
            const quantity = document.getElementById('quantity').value;
            
            if (parseFloat(unitPrice) <= 0) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Price',
                    text: 'Unit price must be greater than 0',
                    confirmButtonColor: '#f59e0b'
                });
                return false;
            }
            
            if (parseInt(quantity) < 0) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Quantity',
                    text: 'Quantity cannot be negative',
                    confirmButtonColor: '#f59e0b'
                });
                return false;
            }
            
            return true;
        });
    });
    </script>
</body>
</html>
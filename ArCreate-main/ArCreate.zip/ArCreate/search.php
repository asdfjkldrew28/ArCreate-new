<?php
// search.php - Search functionality for materials
if (isset($_POST['search']) && !empty($_POST['search'])) {
    $search = $conn->real_escape_string($_POST['search']);
    $query = "SELECT * FROM materials 
              WHERE material_name LIKE '%$search%' 
              OR category LIKE '%$search%' 
              OR description LIKE '%$search%' 
              OR location LIKE '%$search%'
              ORDER BY material_name ASC";
} else {
    $query = "SELECT * FROM materials ORDER BY material_name ASC";
}

$result = $conn->query($query);
<?php
// config.php - Simplified for 3 roles
define('SITE_NAME', 'ArCreate');
define('SITE_LOGO', 'JMJCreations.jpg');
define('SITE_URL', 'http://localhost/arcreate');
define('ADMIN_EMAIL', 'admin@arcreate.com'); // Add admin email for notifications

// Role permissions
$role_permissions = [
    'admin' => ['all'],
    'foreman' => [
        'view_inventory', 'edit_inventory', 'manage_projects', 
        'view_reports', 'manage_materials', 'issue_stock'
    ],
    'client' => ['view_projects', 'view_progress', 'make_payments']
];

// Dashboard redirects
$dashboard_pages = [
    'admin' => 'dashboard_admin.php',
    'foreman' => 'dashboard_foreman.php',
    'client' => 'client_dashboard.php'
];
<?php
// delete_material.php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'foreman'])) {
    header('Location: login.php');
    exit;
}

include 'db_connect.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // User confirmed deletion via POST
    try {
        // Get material info for logging
        $stmt = $conn->prepare("SELECT * FROM materials WHERE material_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $material = $stmt->get_result()->fetch_assoc();
        
        $conn->begin_transaction();
        
        // Log the deletion
        $log_query = "INSERT INTO change_logs (username, action, table_name, record_id, changes) VALUES (?, 'DELETE', 'materials', ?, ?)";
        $log_stmt = $conn->prepare($log_query);
        $changes = json_encode([
            'material_name' => $material['material_name'],
            'category' => $material['category'],
            'quantity' => $material['quantity'],
            'unit_price' => $material['unit_price']
        ]);
        $log_stmt->bind_param("sis", $_SESSION['username'], $id, $changes);
        $log_stmt->execute();
        
        // Delete from related tables
        $tables = ['stock_in', 'stock_out', 'history_logs', 'po_items', 'project_materials'];
        foreach ($tables as $table) {
            $conn->query("DELETE FROM $table WHERE material_id = $id");
        }
        
        // Delete main record
        $conn->query("DELETE FROM materials WHERE material_id = $id");
        
        $conn->commit();
        
        $_SESSION['delete_success'] = "Material deleted successfully!";
        header('Location: index.php');
        exit;
        
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['delete_error'] = "Delete failed: " . $e->getMessage();
        header('Location: index.php');
        exit;
    }
}

// If not POST, show confirmation page
$stmt = $conn->prepare("SELECT material_name FROM materials WHERE material_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$material = $result->fetch_assoc();

if (!$material) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Delete Material - ArCreate</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .hidden-form {
            display: none;
        }
    </style>
</head>
<body>
    <form id="deleteForm" method="post" class="hidden-form">
        <input type="hidden" name="confirm_delete" value="1">
    </form>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        Swal.fire({
            title: 'Delete Material?',
            html: `
                <div style="text-align: center;">
                    <div style="font-size: 4rem; margin-bottom: 15px; color: #ef4444;">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <p style="font-size: 1.2rem; margin-bottom: 10px;">
                        Delete material:<br>
                        <strong>"<?php echo htmlspecialchars($material['material_name']); ?>"</strong>?
                    </p>
                    <div style="background: rgba(239, 68, 68, 0.1); padding: 15px; border-radius: 10px; margin: 15px 0;">
                        <p style="color: #ef4444; font-weight: 600; margin: 0;">
                            ⚠️ This will permanently remove the material and all related records!
                        </p>
                    </div>
                </div>
            `,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#6b7280',
            confirmButtonText: 'Yes, Delete Permanently',
            cancelButtonText: 'Cancel',
            reverseButtons: true,
            allowOutsideClick: false,
            allowEscapeKey: true
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('deleteForm').submit();
            } else {
                window.location.href = 'index.php';
            }
        });
    });
    </script>
</body>
</html>
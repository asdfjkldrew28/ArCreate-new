<?php
session_start();
$allowed_roles = ['admin']; // Removed 'employee' from allowed roles
if (!isset($_SESSION['user_id'])) { 
    header('Location: login.php'); 
    exit; 
}

if (!in_array($_SESSION['role'], $allowed_roles)) {
    header('Location: access_denied.php');
    exit;
}

include 'db_connect.php';

// Check if user has permission to delete (admin/owner only)
if ($_SESSION['role'] !== 'admin') {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Access Denied',
            text: 'You do not have permission to delete items.',
            confirmButtonColor: '#667eea'
        }).then(() => {
            window.location.href='index.php';
        });
    </script>"; 
    exit;
}

$actor = isset($_SESSION['username']) ? $_SESSION['username'] : 'system';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) { 
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Invalid ID',
            text: 'Please select a valid item to delete.',
            confirmButtonColor: '#667eea'
        }).then(() => {
            window.location.href='index.php';
        });
    </script>"; 
    exit; 
}

// Fetch current row
$oldRes = $conn->prepare("SELECT * FROM materials WHERE material_id = ? LIMIT 1");
$oldRes->bind_param("i", $id);
$oldRes->execute();
$oldR = $oldRes->get_result();

if (!$oldR || $oldR->num_rows == 0) { 
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Item Not Found',
            text: 'The item you are trying to delete was not found.',
            confirmButtonColor: '#667eea'
        }).then(() => {
            window.location.href='index.php';
        });
    </script>"; 
    exit; 
}

$old = $oldR->fetch_assoc();
$oldRes->close();

try {
    $conn->begin_transaction();
    
    // First delete from child tables
    $tables = ['stock_in', 'stock_out', 'history_logs'];
    foreach ($tables as $table) {
        $conn->query("DELETE FROM $table WHERE material_id = $id");
    }
    
    // Then delete from main table
    $conn->query("DELETE FROM materials WHERE material_id = $id");
    
    $conn->commit();
    header("Location: index.php?delete_success=1");
    exit;
} catch (Exception $e) {
    $conn->rollback();
    die("Delete failed: " . $e->getMessage());
}
?>
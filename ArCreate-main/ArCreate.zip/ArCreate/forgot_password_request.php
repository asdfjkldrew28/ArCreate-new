<?php
// forgot_password_request.php - Handle forgot password requests
session_start();
include 'db_connect.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    
    // Check if user exists
    $stmt = $conn->prepare("SELECT user_id, username, full_name, email, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Get admin info for notification
        $admin_stmt = $conn->prepare("SELECT username, full_name, email FROM users WHERE role = 'admin' LIMIT 1");
        $admin_stmt->execute();
        $admin = $admin_stmt->get_result()->fetch_assoc();
        
        // Create password reset request
        $token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Store request in database
        $insert_stmt = $conn->prepare("INSERT INTO password_reset_requests (user_id, username, token, expires_at, status) VALUES (?, ?, ?, ?, 'pending')");
        $insert_stmt->bind_param("isss", $user['user_id'], $username, $token, $expires_at);
        
        if ($insert_stmt->execute()) {
            // Log the request
            $log_query = "INSERT INTO change_logs (username, action, table_name, record_id, changes) VALUES (?, 'INSERT', 'password_reset_requests', ?, ?)";
            $log_stmt = $conn->prepare($log_query);
            $changes = json_encode([
                'username' => $username,
                'status' => 'pending',
                'admin_notified' => true
            ]);
            $request_id = $conn->insert_id;
            $log_stmt->bind_param("sis", $username, $request_id, $changes);
            $log_stmt->execute();
            
            echo json_encode([
                'success' => true,
                'message' => "Password reset request submitted successfully. The system administrator ($admin[full_name]) has been notified and will process your request shortly."
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to submit request. Please try again.'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Username not found in our system.'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method.'
    ]);
}
?>
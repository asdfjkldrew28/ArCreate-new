<?php
// forgot_password.php - Password reset with admin authorization
session_start();
include 'db_connect.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $admin_username = $conn->real_escape_string($_POST['admin_username']);
    $admin_password = $_POST['admin_password'];
    
    // Verify admin credentials
    $admin_stmt = $conn->prepare("SELECT user_id, password FROM users WHERE username = ? AND role = 'admin' LIMIT 1");
    $admin_stmt->bind_param("s", $admin_username);
    $admin_stmt->execute();
    $admin_result = $admin_stmt->get_result();
    
    if ($admin_result->num_rows === 1) {
        $admin = $admin_result->fetch_assoc();
        
        if (password_verify($admin_password, $admin['password'])) {
            // Admin verified, now reset user's password
            $new_password = bin2hex(random_bytes(4)); // Generate random password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $reset_stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
            $reset_stmt->bind_param("ss", $hashed_password, $username);
            
            if ($reset_stmt->execute()) {
                if ($reset_stmt->affected_rows > 0) {
                    $message = "Password reset successful! New password for '$username' is: <strong>$new_password</strong><br>Please change it after logging in.";
                    
                    // Log the action
                    $log_query = "INSERT INTO change_logs (username, action, table_name, record_id, changes) VALUES (?, 'UPDATE', 'users', ?, ?)";
                    $log_stmt = $conn->prepare($log_query);
                    $changes = json_encode([
                        'action' => 'password_reset',
                        'reset_by_admin' => $admin_username,
                        'username' => $username
                    ]);
                    $log_stmt->bind_param("sis", $admin_username, $admin['user_id'], $changes);
                    $log_stmt->execute();
                } else {
                    $error = "Username not found or no changes made.";
                }
            } else {
                $error = "Reset failed: " . $conn->error;
            }
        } else {
            $error = "Invalid admin password.";
        }
    } else {
        $error = "Invalid admin username or not an admin account.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Reset Password - ArCreate</title>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.reset-container {
    background: rgba(255, 255, 255, 0.95);
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 500px;
}

h2 {
    color: #764ba2;
    text-align: center;
    margin-bottom: 30px;
    font-size: 2rem;
    font-weight: 600;
}

h2 i {
    margin-right: 10px;
}

.form-group {
    margin-bottom: 25px;
}

label {
    display: block;
    margin-bottom: 8px;
    color: #333;
    font-weight: 600;
}

input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #667eea;
    border-radius: 10px;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.btn-reset {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-top: 10px;
}

.btn-reset:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
}

.error {
    background: #ffe6ef;
    color: #a7002a;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
    font-weight: 600;
}

.success {
    background: #d1fae5;
    color: #065f46;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
    font-weight: 600;
}

.info-box {
    background: #f0f9ff;
    border: 2px solid #0ea5e9;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 25px;
}

.info-box h4 {
    color: #0ea5e9;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.back-link {
    text-align: center;
    margin-top: 20px;
}

.back-link a {
    color: #764ba2;
    text-decoration: none;
    font-weight: 600;
}
</style>
</head>
<body>
<div class="reset-container">
    <h2><i class="fas fa-key"></i> Reset Password</h2>
    
    <div class="info-box">
        <h4><i class="fas fa-shield-alt"></i> Admin Authorization Required</h4>
        <p style="color: #666; font-size: 0.9rem;">
            For security reasons, password resets require admin authorization. 
            Please contact your system administrator or enter admin credentials below.
        </p>
    </div>
    
    <?php if($error): ?>
        <div class="error">❌ <?php echo $error; ?></div>
    <?php endif; ?>
    
    <?php if($message): ?>
        <div class="success">✅ <?php echo $message; ?></div>
    <?php endif; ?>

    <form method="post" id="resetForm">
        <div class="form-group">
            <label for="username"><i class="fas fa-user"></i> Username to Reset</label>
            <input type="text" id="username" name="username" required placeholder="Enter the username needing reset">
        </div>
        
        <div class="form-group">
            <label for="admin_username"><i class="fas fa-crown"></i> Admin Username</label>
            <input type="text" id="admin_username" name="admin_username" required placeholder="Enter admin username">
        </div>
        
        <div class="form-group">
            <label for="admin_password"><i class="fas fa-lock"></i> Admin Password</label>
            <input type="password" id="admin_password" name="admin_password" required placeholder="Enter admin password">
        </div>
        
        <button type="submit" class="btn-reset">🔐 Reset Password with Admin Auth</button>
    </form>
    
    <div class="back-link">
        <a href="login.php"><i class="fas fa-arrow-left"></i> Back to Login</a>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('username').focus();
    
    // Form validation
    document.getElementById('resetForm').addEventListener('submit', function(e) {
        const adminUsername = document.getElementById('admin_username').value;
        const username = document.getElementById('username').value;
        
        if (adminUsername === username) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Same Account',
                text: 'Admin cannot reset their own password through this form.',
                confirmButtonColor: '#f59e0b'
            });
            return false;
        }
        
        return true;
    });
});
</script>
</body>
</html>
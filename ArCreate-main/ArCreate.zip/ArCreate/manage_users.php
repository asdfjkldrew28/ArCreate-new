<?php
// manage_users.php - Admin only user creation
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

include 'db_connect.php';

$success = false;
$error = '';

// Check if admin exists - there can only be 1 admin
$admin_exists = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'")->fetch_assoc()['count'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Check if it's user creation or password reset
        if (isset($_POST['action']) && $_POST['action'] === 'create_user') {
            $username = $conn->real_escape_string($_POST['username']);
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $role = $conn->real_escape_string($_POST['role']);
            $full_name = $conn->real_escape_string($_POST['full_name']);
            $email = $conn->real_escape_string($_POST['email']);
            $phone = $conn->real_escape_string($_POST['phone']);
            
            // Check if username exists
            $check_stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
            $check_stmt->bind_param("s", $username);
            $check_stmt->execute();
            
            if ($check_stmt->get_result()->num_rows > 0) {
                $error = "Username already exists!";
            } else {
                // Prevent creating another admin (only 1 admin allowed)
                if ($role === 'admin') {
                    $error = "There can only be 1 administrator in the system.";
                } else {
                    $stmt = $conn->prepare("INSERT INTO users (username, password, role, full_name, email, phone) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("ssssss", $username, $password, $role, $full_name, $email, $phone);
                    
                    if ($stmt->execute()) {
                        $success = true;
                        // Log the action
                        $log_query = "INSERT INTO change_logs (username, action, table_name, record_id, changes) VALUES (?, 'INSERT', 'users', ?, ?)";
                        $log_stmt = $conn->prepare($log_query);
                        $changes = json_encode([
                            'username' => $username,
                            'role' => $role,
                            'full_name' => $full_name
                        ]);
                        $record_id = $conn->insert_id;
                        $log_stmt->bind_param("sis", $_SESSION['username'], $record_id, $changes);
                        $log_stmt->execute();
                    } else {
                        $error = "Failed to create user: " . $conn->error;
                    }
                }
            }
        } elseif (isset($_POST['action']) && $_POST['action'] === 'update_profile') {
            // Update admin's own profile
            $current_user_id = $_SESSION['user_id'];
            $username = $conn->real_escape_string($_POST['username']);
            $full_name = $conn->real_escape_string($_POST['full_name']);
            $email = $conn->real_escape_string($_POST['email']);
            $phone = $conn->real_escape_string($_POST['phone']);
            
            // Check if username is taken by another user
            $check_stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ? AND user_id != ?");
            $check_stmt->bind_param("si", $username, $current_user_id);
            $check_stmt->execute();
            
            if ($check_stmt->get_result()->num_rows > 0) {
                $error = "Username already taken by another user!";
            } else {
                $stmt = $conn->prepare("UPDATE users SET username = ?, full_name = ?, email = ?, phone = ? WHERE user_id = ?");
                $stmt->bind_param("ssssi", $username, $full_name, $email, $phone, $current_user_id);
                
                if ($stmt->execute()) {
                    // Update session
                    $_SESSION['username'] = $username;
                    $_SESSION['full_name'] = $full_name;
                    
                    $success = true;
                    // Log the action
                    $log_query = "INSERT INTO change_logs (username, action, table_name, record_id, changes) VALUES (?, 'UPDATE', 'users', ?, ?)";
                    $log_stmt = $conn->prepare($log_query);
                    $changes = json_encode([
                        'username' => $username,
                        'full_name' => $full_name,
                        'email' => $email,
                        'phone' => $phone
                    ]);
                    $log_stmt->bind_param("sis", $_SESSION['username'], $current_user_id, $changes);
                    $log_stmt->execute();
                } else {
                    $error = "Failed to update profile: " . $conn->error;
                }
            }
        } elseif (isset($_POST['action']) && $_POST['action'] === 'change_password') {
            // Change admin's own password
            $current_user_id = $_SESSION['user_id'];
            $current_password = $_POST['current_password'];
            $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            
            // Verify current password
            $check_stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ?");
            $check_stmt->bind_param("i", $current_user_id);
            $check_stmt->execute();
            $user = $check_stmt->get_result()->fetch_assoc();
            
            if (password_verify($current_password, $user['password'])) {
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $stmt->bind_param("si", $new_password, $current_user_id);
                
                if ($stmt->execute()) {
                    $success = true;
                    // Log the action
                    $log_query = "INSERT INTO change_logs (username, action, table_name, record_id, changes) VALUES (?, 'UPDATE', 'users', ?, ?)";
                    $log_stmt = $conn->prepare($log_query);
                    $changes = json_encode([
                        'action' => 'password_change',
                        'changed_by' => 'self'
                    ]);
                    $log_stmt->bind_param("sis", $_SESSION['username'], $current_user_id, $changes);
                    $log_stmt->execute();
                } else {
                    $error = "Failed to change password: " . $conn->error;
                }
            } else {
                $error = "Current password is incorrect!";
            }
        } elseif (isset($_POST['action']) && $_POST['action'] === 'reset_user_password') {
            // Reset another user's password
            $user_id = (int)$_POST['user_id'];
            $new_password = bin2hex(random_bytes(4)); // Generate random password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $stmt->bind_param("si", $hashed_password, $user_id);
            
            if ($stmt->execute()) {
                // Get user info for success message
                $user_stmt = $conn->prepare("SELECT username FROM users WHERE user_id = ?");
                $user_stmt->bind_param("i", $user_id);
                $user_stmt->execute();
                $user_result = $user_stmt->get_result();
                $user = $user_result->fetch_assoc();
                
                $success = "Password reset for user '{$user['username']}'. New password: <strong>{$new_password}</strong>";
                
                // Log the action
                $log_query = "INSERT INTO change_logs (username, action, table_name, record_id, changes) VALUES (?, 'UPDATE', 'users', ?, ?)";
                $log_stmt = $conn->prepare($log_query);
                $changes = json_encode([
                    'action' => 'password_reset',
                    'reset_by_admin' => $_SESSION['username'],
                    'username' => $user['username']
                ]);
                $log_stmt->bind_param("sis", $_SESSION['username'], $user_id, $changes);
                $log_stmt->execute();
            } else {
                $error = "Failed to reset password: " . $conn->error;
            }
        }
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Fetch all users
$users = $conn->query("SELECT * FROM users ORDER BY role, username");

// Get current admin info
$current_user_id = $_SESSION['user_id'];
$admin_info_stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$admin_info_stmt->bind_param("i", $current_user_id);
$admin_info_stmt->execute();
$admin_info = $admin_info_stmt->get_result()->fetch_assoc();

// Fetch pending password reset requests
$reset_requests = $conn->query("SELECT prr.*, u.full_name, u.email, u.phone FROM password_reset_requests prr JOIN users u ON prr.user_id = u.user_id WHERE prr.status = 'pending' ORDER BY prr.created_at DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Manage Users - ArCreate</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #1e40af;
            font-size: 2rem;
        }
        
        .header-icon {
            font-size: 2rem;
            color: #667eea;
        }
        
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            border-bottom: 2px solid #e5e7eb;
            padding-bottom: 10px;
            flex-wrap: wrap;
        }
        
        .tab {
            padding: 10px 20px;
            border: none;
            background: none;
            font-size: 1rem;
            font-weight: 600;
            color: #6b7280;
            cursor: pointer;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .tab.active {
            background: #667eea;
            color: white;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        input, select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        input:focus, select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-secondary {
            background: #f3f4f6;
            color: #4b5563;
        }
        
        .btn-success {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .users-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .users-table th {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 15px;
            text-align: left;
        }
        
        .users-table td {
            padding: 15px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .users-table tr:hover {
            background: rgba(102, 126, 234, 0.05);
        }
        
        .role-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .role-admin { background: linear-gradient(135deg, #667eea, #764ba2); color: white; }
        .role-foreman { background: linear-gradient(135deg, #f59e0b, #d97706); color: white; }
        .role-client { background: linear-gradient(135deg, #6b7280, #4b5563); color: white; }
        
        .admin-notice {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
            border: 2px solid #667eea;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .admin-notice h4 {
            color: #667eea;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .reset-requests {
            background: #fef3c7;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            border: 2px solid #f59e0b;
        }
        
        .reset-request-item {
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
            border: 1px solid #e5e7eb;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div style="display: flex; align-items: center; gap: 15px;">
                <div class="header-icon">
                    <i class="fas fa-users-cog"></i>
                </div>
                <div>
                    <h1>User Management</h1>
                    <p style="color: #6b7280;">System administration and user management</p>
                </div>
            </div>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Inventory
            </a>
        </div>
        
        <!-- Admin Notice -->
        <div class="admin-notice">
            <h4><i class="fas fa-crown"></i> System Administrator Control Panel</h4>
            <p style="color: #4b5563; margin-bottom: 10px;">
                <strong>Current Admin:</strong> <?php echo htmlspecialchars($admin_info['full_name']); ?> (<?php echo htmlspecialchars($admin_info['username']); ?>)
            </p>
            <p style="color: #667eea; font-weight: 600;">
                <i class="fas fa-info-circle"></i> There is only 1 administrator in the system. You cannot create additional admin accounts.
            </p>
        </div>
        
        <div class="tabs">
            <button class="tab active" onclick="switchTab('create')">Create New User</button>
            <button class="tab" onclick="switchTab('profile')">My Profile</button>
            <button class="tab" onclick="switchTab('view')">View All Users</button>
            <button class="tab" onclick="switchTab('password')">Reset User Password</button>
        </div>
        
        <?php if ($reset_requests && $reset_requests->num_rows > 0): ?>
        <div class="reset-requests">
            <h4 style="color: #92400e; margin-bottom: 15px;">
                <i class="fas fa-exclamation-circle"></i> Pending Password Reset Requests
            </h4>
            <?php while($request = $reset_requests->fetch_assoc()): ?>
            <div class="reset-request-item">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                    <div>
                        <strong><?php echo htmlspecialchars($request['full_name']); ?></strong>
                        <div style="font-size: 0.9rem; color: #6b7280;">
                            Username: <?php echo htmlspecialchars($request['username']); ?> | 
                            Requested: <?php echo date('M d, Y H:i', strtotime($request['created_at'])); ?>
                        </div>
                    </div>
                    <button class="btn btn-warning btn-sm" onclick="processResetRequest(<?php echo $request['user_id']; ?>, '<?php echo htmlspecialchars($request['username']); ?>')">
                        <i class="fas fa-key"></i> Reset Password
                    </button>
                </div>
                <div style="font-size: 0.8rem; color: #9ca3af;">
                    Contact: <?php echo htmlspecialchars($request['email'] ?: $request['phone'] ?: 'No contact info'); ?>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
        <div id="errorAlert" style="display: none;"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
        <div id="successAlert" style="display: none;"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <!-- Create User Tab -->
        <div id="create-tab" class="tab-content active">
            <h3>Create New User Account</h3>
            
            <form method="post" id="createUserForm">
                <input type="hidden" name="action" value="create_user">
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="username" class="required">Username</label>
                        <input type="text" id="username" name="username" required 
                               placeholder="Enter unique username">
                    </div>
                    
                    <div class="form-group">
                        <label for="password" class="required">Password</label>
                        <input type="password" id="password" name="password" required 
                               placeholder="Enter password (min. 6 characters)">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="full_name" class="required">Full Name</label>
                        <input type="text" id="full_name" name="full_name" required 
                               placeholder="Enter full name">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" 
                               placeholder="user@example.com">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" 
                               placeholder="+63 912 345 6789">
                    </div>
                    
                    <div class="form-group">
                        <label for="role" class="required">Role</label>
                        <select id="role" name="role" required>
                            <option value="">Select Role</option>
                            <option value="foreman">👷 Site Foreman</option>
                            <option value="client">👤 Client</option>
                        </select>
                        <small style="color: #6b7280; font-size: 0.9rem;">
                            <i class="fas fa-info-circle"></i> Admin role is not available - only 1 admin allowed
                        </small>
                    </div>
                </div>
                
                <div class="btn-group">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-user-plus"></i> Create User Account
                    </button>
                </div>
            </form>
        </div>
        
        <!-- My Profile Tab -->
        <div id="profile-tab" class="tab-content">
            <div class="form-row">
                <!-- Update Profile Form -->
                <div style="flex: 1;">
                    <h3>Update My Profile</h3>
                    <form method="post" id="updateProfileForm">
                        <input type="hidden" name="action" value="update_profile">
                        
                        <div class="form-group">
                            <label for="profile_username" class="required">Username</label>
                            <input type="text" id="profile_username" name="username" required 
                                   value="<?php echo htmlspecialchars($admin_info['username']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="profile_full_name" class="required">Full Name</label>
                            <input type="text" id="profile_full_name" name="full_name" required 
                                   value="<?php echo htmlspecialchars($admin_info['full_name']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="profile_email">Email Address</label>
                            <input type="email" id="profile_email" name="email" 
                                   value="<?php echo htmlspecialchars($admin_info['email']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="profile_phone">Phone Number</label>
                            <input type="tel" id="profile_phone" name="phone" 
                                   value="<?php echo htmlspecialchars($admin_info['phone']); ?>">
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Profile
                        </button>
                    </form>
                </div>
                
                <!-- Change Password Form -->
                <div style="flex: 1;">
                    <h3>Change My Password</h3>
                    <form method="post" id="changePasswordForm">
                        <input type="hidden" name="action" value="change_password">
                        
                        <div class="form-group">
                            <label for="current_password" class="required">Current Password</label>
                            <input type="password" id="current_password" name="current_password" required 
                                   placeholder="Enter current password">
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password" class="required">New Password</label>
                            <input type="password" id="new_password" name="new_password" required 
                                   placeholder="Enter new password (min. 6 characters)">
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password" class="required">Confirm New Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" required 
                                   placeholder="Confirm new password">
                        </div>
                        
                        <button type="submit" class="btn btn-warning">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- View Users Tab -->
        <div id="view-tab" class="tab-content">
            <h3>All System Users</h3>
            
            <table class="users-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Full Name</th>
                        <th>Role</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Created</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($users && $users->num_rows > 0): ?>
                        <?php while($user = $users->fetch_assoc()): 
                            $role_classes = [
                                'admin' => 'role-admin',
                                'foreman' => 'role-foreman',
                                'client' => 'role-client'
                            ];
                        ?>
                        <tr>
                            <td>#<?php echo $user['user_id']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                                <?php if ($user['user_id'] == $_SESSION['user_id']): ?>
                                    <span style="color: #667eea; font-size: 0.8rem;">(You)</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                            <td>
                                <span class="role-badge <?php echo $role_classes[$user['role']] ?? 'role-client'; ?>">
                                    <?php 
                                    $role_display = [
                                        'admin' => '👑 Admin',
                                        'foreman' => '👷 Foreman',
                                        'client' => '👤 Client'
                                    ];
                                    echo $role_display[$user['role']] ?? ucfirst($user['role']); 
                                    ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['phone']); ?></td>
                            <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                            <td>
                                <span style="color: <?php echo $user['status'] == 'active' ? '#10b981' : '#ef4444'; ?>; font-weight: 600;">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px;">
                                <div style="font-size: 3rem; margin-bottom: 20px;">👥</div>
                                <h3>No Users Found</h3>
                                <p>No user accounts in the system.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Reset User Password Tab -->
        <div id="password-tab" class="tab-content">
            <h3>Reset User Password</h3>
            <p style="color: #6b7280; margin-bottom: 20px;">
                Select a user to reset their password. A new random password will be generated.
            </p>
            
            <form method="post" id="resetPasswordForm">
                <input type="hidden" name="action" value="reset_user_password">
                
                <div class="form-group">
                    <label for="user_id" class="required">Select User</label>
                    <select id="user_id" name="user_id" required>
                        <option value="">Select a user</option>
                        <?php 
                        $all_users = $conn->query("SELECT user_id, username, full_name, role FROM users ORDER BY role, username");
                        while($user = $all_users->fetch_assoc()): 
                            if ($user['user_id'] != $_SESSION['user_id']): // Don't show admin for self-reset
                        ?>
                        <option value="<?php echo $user['user_id']; ?>">
                            <?php echo htmlspecialchars($user['full_name']); ?> (<?php echo htmlspecialchars($user['username']); ?>)
                            - <?php echo ucfirst($user['role']); ?>
                        </option>
                        <?php 
                            endif;
                        endwhile; 
                        ?>
                    </select>
                </div>
                
                <div class="btn-group">
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-key"></i> Reset User Password
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const successAlert = document.getElementById('successAlert');
        const errorAlert = document.getElementById('errorAlert');
        
        if (successAlert) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                html: successAlert.textContent,
                confirmButtonColor: '#667eea',
                timer: 5000,
                timerProgressBar: true
            });
        }
        
        if (errorAlert) {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: errorAlert.textContent,
                confirmButtonColor: '#ef4444'
            });
        }
        
        // Create User Form validation
        const createUserForm = document.getElementById('createUserForm');
        if (createUserForm) {
            createUserForm.addEventListener('submit', function(e) {
                const password = document.getElementById('password').value;
                const username = document.getElementById('username').value;
                
                if (password.length < 6) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'warning',
                        title: 'Weak Password',
                        text: 'Password must be at least 6 characters long',
                        confirmButtonColor: '#f59e0b'
                    });
                    return false;
                }
                
                if (username.length < 3) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'warning',
                        title: 'Invalid Username',
                        text: 'Username must be at least 3 characters long',
                        confirmButtonColor: '#f59e0b'
                    });
                    return false;
                }
                
                return true;
            });
        }
        
        // Change Password Form validation
        const changePasswordForm = document.getElementById('changePasswordForm');
        if (changePasswordForm) {
            changePasswordForm.addEventListener('submit', function(e) {
                const newPassword = document.getElementById('new_password').value;
                const confirmPassword = document.getElementById('confirm_password').value;
                
                if (newPassword.length < 6) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'warning',
                        title: 'Weak Password',
                        text: 'Password must be at least 6 characters long',
                        confirmButtonColor: '#f59e0b'
                    });
                    return false;
                }
                
                if (newPassword !== confirmPassword) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'warning',
                        title: 'Password Mismatch',
                        text: 'New password and confirmation do not match',
                        confirmButtonColor: '#f59e0b'
                    });
                    return false;
                }
                
                return true;
            });
        }
        
        // Reset Password Form confirmation
        const resetPasswordForm = document.getElementById('resetPasswordForm');
        if (resetPasswordForm) {
            resetPasswordForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const userId = document.getElementById('user_id').value;
                const userName = document.getElementById('user_id').options[document.getElementById('user_id').selectedIndex].text;
                
                if (!userId) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No User Selected',
                        text: 'Please select a user to reset their password',
                        confirmButtonColor: '#f59e0b'
                    });
                    return false;
                }
                
                Swal.fire({
                    title: 'Reset Password?',
                    html: `
                        <div style="text-align: center;">
                            <div style="font-size: 3rem; margin-bottom: 15px; color: #f59e0b;">
                                <i class="fas fa-key"></i>
                            </div>
                            <p style="font-size: 1.1rem; margin-bottom: 10px;">
                                Reset password for:<br>
                                <strong>${userName}</strong>?
                            </p>
                            <p style="color: #666; font-size: 0.9rem;">
                                A new random password will be generated and displayed.
                            </p>
                        </div>
                    `,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#f59e0b',
                    cancelButtonColor: '#6b7280',
                    confirmButtonText: 'Yes, Reset Password',
                    cancelButtonText: 'Cancel',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        resetPasswordForm.submit();
                    }
                });
                
                return false;
            });
        }
    });
    
    function switchTab(tabName) {
        // Update tabs
        document.querySelectorAll('.tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`.tab[onclick*="${tabName}"]`).classList.add('active');
        
        // Update content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`${tabName}-tab`).classList.add('active');
    }
    
    function processResetRequest(userId, userName) {
        Swal.fire({
            title: 'Reset Password?',
            html: `
                <div style="text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 15px; color: #f59e0b;">
                        <i class="fas fa-key"></i>
                    </div>
                    <p style="font-size: 1.1rem; margin-bottom: 10px;">
                        Process password reset request for:<br>
                        <strong>${userName}</strong>?
                    </p>
                    <p style="color: #666; font-size: 0.9rem;">
                        This will generate a new random password.
                    </p>
                </div>
            `,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#f59e0b',
            cancelButtonColor: '#6b7280',
            confirmButtonText: 'Yes, Reset Now',
            cancelButtonText: 'Cancel',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Submit form to reset password
                const form = document.createElement('form');
                form.method = 'post';
                form.style.display = 'none';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'reset_user_password';
                form.appendChild(actionInput);
                
                const userIdInput = document.createElement('input');
                userIdInput.type = 'hidden';
                userIdInput.name = 'user_id';
                userIdInput.value = userId;
                form.appendChild(userIdInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        });
    }
    </script>
</body>
</html>